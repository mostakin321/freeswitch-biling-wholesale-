<?php
namespace App\Filament\Resources\Billing\AniMaps;
use App\Models\Billing\AniMap;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class AniMapResource extends Resource {
    protected static ?string $model           = AniMap::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-phone';
    protected static ?string $navigationLabel = 'ANI Map (Caller ID)';
    protected static ?int    $navigationSort  = 15;
    protected static ?string $modelLabel      = 'ANI Map';
    protected static ?string $pluralModelLabel = 'ANI Maps';
    public static function form(Form $form): Form { return Schemas\AniMapForm::configure($form); }
    public static function table(Table $table): Table { return Tables\AniMapsTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListAniMaps::route('/'),
            'create' => Pages\CreateAniMap::route('/create'),
            'edit'   => Pages\EditAniMap::route('/{record}/edit'),
        ];
    }
}
