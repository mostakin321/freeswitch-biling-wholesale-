<?php
namespace App\Filament\Resources\Billing\Dids;
use App\Models\Billing\Did;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class DidResource extends Resource {
    protected static ?string $model          = Did::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-phone-arrow-down-left';
    protected static ?string $navigationLabel = 'DIDs';
    protected static ?int    $navigationSort  = 4;
    public static function form(Form $form): Form { return Schemas\DidForm::configure($form); }
    public static function table(Table $table): Table { return Tables\DidsTable::configure($table); }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListDids::route('/'),
            'create' => Pages\CreateDid::route('/create'),
            'edit'   => Pages\EditDid::route('/{record}/edit'),
        ];
    }
}
