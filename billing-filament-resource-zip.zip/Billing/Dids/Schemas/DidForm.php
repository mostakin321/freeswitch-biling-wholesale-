<?php
namespace App\Filament\Resources\Billing\Dids\Schemas;

use App\Models\Billing\Account;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Illuminate\Support\Facades\DB;

class DidForm
{
    // ASTPP call_type values
    const CALL_TYPES = [
        0 => 'Local Extension',
        1 => 'SIP URI',
        2 => 'Direct IP',
        3 => 'Other / Custom',
        4 => 'Transfer (Forward)',
    ];

    public static function configure(Form $form): Form
    {
        return $form->schema([

            Section::make('DID Information')
                ->icon('heroicon-o-phone-arrow-down-left')
                ->columns(3)
                ->schema([
                    TextInput::make('number')
                        ->label('DID Number')
                        ->required()
                        ->placeholder('+8809612345678')
                        ->helperText('Full DID number in E.164 format'),

                    Select::make('country_id')
                        ->label('Country')
                        ->options(fn() => DB::table('countrycode')
                            ->where('status', 0)->orderBy('name')->pluck('country', 'id'))
                        ->searchable()
                        ->live()
                        ->afterStateUpdated(function (Get $get, Set $set, $state) {
                            if (!$state) return;
                            $c = DB::table('countrycode')->find($state);
                            if ($c) $set('country_code', $c->code);
                        }),

                    TextInput::make('province')
                        ->label('Province / State')
                        ->placeholder('Dhaka'),

                    TextInput::make('city')
                        ->label('City')
                        ->placeholder('Dhaka'),

                    Select::make('accountid')
                        ->label('Assigned Account')
                        ->options(fn() => Account::where('status', 0)
                            ->where('deleted', 0)
                            ->whereIn('type', [0, 3])
                            ->get()
                            ->mapWithKeys(fn($a) => [
                                $a->id => $a->number . ' — ' . ($a->company_name ?: $a->first_name)
                            ]))
                        ->searchable()
                        ->nullable()
                        ->helperText('Customer or reseller this DID is assigned to'),

                    Select::make('parent_id')
                        ->label('Reseller Pool Owner')
                        ->options(fn() => Account::where('type', 3)
                            ->where('status', 0)->pluck('company_name', 'id'))
                        ->searchable()
                        ->nullable()
                        ->helperText('Reseller who manages this DID pool'),

                    Select::make('status')
                        ->options([0 => 'Active', 1 => 'Inactive'])
                        ->default(0),
                ]),

            Section::make('Call Routing')
                ->icon('heroicon-o-arrow-path')
                ->columns(3)
                ->schema([
                    Select::make('call_type')
                        ->label('Call Type')
                        ->options(self::CALL_TYPES)
                        ->default(0)
                        ->required()
                        ->live()
                        ->helperText('How to route inbound calls on this DID'),

                    Textarea::make('extensions')
                        ->label('Destination / Extensions')
                        ->rows(2)
                        ->placeholder('1001 or sip:user@domain.com')
                        ->helperText('Extension number, SIP URI, or IP address. Comma-separate for multiple.')
                        ->columnSpan(2),

                    TextInput::make('leg_timeout')
                        ->label('Leg Timeout (sec)')
                        ->numeric()
                        ->default(30)
                        ->helperText('Ring timeout before voicemail/next'),

                    TextInput::make('maxchannels')
                        ->label('Max Concurrent Calls')
                        ->numeric()
                        ->default(0)
                        ->helperText('0 = unlimited'),

                    Toggle::make('always')
                        ->label('Always Forward')
                        ->default(false)
                        ->inline(false)
                        ->live()
                        ->helperText('Always forward to alternate destination'),

                    TextInput::make('always_destination')
                        ->label('Always Forward To')
                        ->placeholder('sip:forward@domain.com')
                        ->visible(fn(Get $get): bool => (bool)$get('always'))
                        ->helperText('Destination when always forward is enabled'),
                ]),

            Section::make('Billing')
                ->icon('heroicon-o-currency-dollar')
                ->columns(3)
                ->schema([
                    TextInput::make('cost')
                        ->label('Per-Minute Rate ($)')
                        ->numeric()
                        ->default(0)
                        ->helperText('Cost per minute for inbound calls'),

                    TextInput::make('setup')
                        ->label('Setup Fee ($)')
                        ->numeric()
                        ->default(0)
                        ->helperText('One-time setup fee'),

                    TextInput::make('monthlycost')
                        ->label('Monthly Cost ($)')
                        ->numeric()
                        ->default(0)
                        ->helperText('Recurring monthly charge'),

                    TextInput::make('init_inc')
                        ->label('Initial Increment (sec)')
                        ->numeric()
                        ->default(60),

                    TextInput::make('inc')
                        ->label('Increment (sec)')
                        ->numeric()
                        ->default(1),

                    DatePicker::make('next_billing_date')
                        ->label('Next Billing Date'),
                ]),
        ]);
    }
}
