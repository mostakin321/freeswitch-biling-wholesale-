<?php
namespace App\Filament\Resources\Billing\Dids\Tables;

use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Filters\SelectFilter;
use Filament\Support\Enums\FontWeight;
use Illuminate\Support\Facades\DB;

class DidsTable
{
    public static function configure(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('did_number')
                ->label('DID')
                ->searchable()
                ->sortable()
                ->weight(FontWeight::Medium)
                ->copyable(),

            TextColumn::make('country_code')
                ->label('Country')
                ->badge()
                ->color('info')
                ->formatStateUsing(fn(string $state): string =>
                    DB::table('countrycode')->where('code', $state)->value('name') ?: $state
                ),

            TextColumn::make('did_category')
                ->label('Category')
                ->badge()
                ->color(fn(string $state): string => match($state) {
                    'geographic' => 'success',
                    'mobile'     => 'info',
                    'tollfree'   => 'warning',
                    'premium'    => 'danger',
                    default      => 'gray',
                }),

            TextColumn::make('account.number')
                ->label('Account')
                ->default('Unassigned')
                ->color(fn($state): string => $state === 'Unassigned' ? 'gray' : 'success'),

            TextColumn::make('destination')
                ->label('Routes To')
                ->default('—'),

            TextColumn::make('monthly_fee')
                ->label('Monthly')
                ->money('usd'),

            TextColumn::make('next_billing_date')
                ->label('Next Bill')
                ->date()
                ->color(fn($state): string =>
                    $state && \Carbon\Carbon::parse($state)->isPast() ? 'danger' : 'success'
                ),

            TextColumn::make('status')
                ->badge()
                ->formatStateUsing(fn(string $state): string => $state === '0' ? 'Active' : 'Inactive')
                ->color(fn(string $state): string => $state === '0' ? 'success' : 'danger'),
        ])
        ->filters([
            SelectFilter::make('country_code')
                ->label('Country')
                ->options(fn() => DB::table('countrycode')
                    ->where('status', 0)
                    ->pluck('call_type', 'id')),

            SelectFilter::make('did_category')
                ->label('Category')
                ->options([
                    'geographic' => 'Geographic',
                    'mobile'     => 'Mobile',
                    'tollfree'   => 'Toll Free',
                    'premium'    => 'Premium',
                ]),

            SelectFilter::make('status')
                ->options([0 => 'Active', 1 => 'Inactive']),
        ])
        ->actions([EditAction::make(), DeleteAction::make()])
        ->defaultSort('did_number');
    }
}
