<?php
namespace App\Filament\Resources\Billing\Products;
use App\Models\Billing\Product;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class ProductResource extends Resource {
    protected static ?string $model           = Product::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-gift';
    protected static ?string $navigationLabel = 'Products';
    protected static ?int    $navigationSort  = 8;
    public static function form(Form $form): Form { return Schemas\ProductForm::configure($form); }
    public static function table(Table $table): Table { return Tables\ProductsTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit'   => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
