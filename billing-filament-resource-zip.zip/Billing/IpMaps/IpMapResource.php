<?php
namespace App\Filament\Resources\Billing\IpMaps;
use App\Models\Billing\IpMap;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class IpMapResource extends Resource {
    protected static ?string $model           = IpMap::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-server';
    protected static ?string $navigationLabel = 'IP Map';
    protected static ?int    $navigationSort  = 16;
    protected static ?string $modelLabel      = 'IP Map';
    protected static ?string $pluralModelLabel = 'IP Maps';
    public static function form(Form $form): Form { return Schemas\IpMapForm::configure($form); }
    public static function table(Table $table): Table { return Tables\IpMapsTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListIpMaps::route('/'),
            'create' => Pages\CreateIpMap::route('/create'),
            'edit'   => Pages\EditIpMap::route('/{record}/edit'),
        ];
    }
}
