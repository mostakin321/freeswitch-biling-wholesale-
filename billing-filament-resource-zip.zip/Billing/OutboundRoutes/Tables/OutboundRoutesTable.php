<?php
namespace App\Filament\Resources\Billing\OutboundRoutes\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Support\Enums\FontWeight;
class OutboundRoutesTable {
    public static function configure(Table $table): Table {
        return $table->columns([
            TextColumn::make('pricelist.name')->label('Rate Plan')->badge()->color('info'),
            TextColumn::make('prefix')->searchable()->sortable()->weight(FontWeight::Medium),
            TextColumn::make('comment')->label('Destination')->default('—'),
            TextColumn::make('trunk.name')->label('Trunk')->badge()->color('warning'),
            TextColumn::make('cost')->label('Cost/Min')->money('usd')->sortable(),
            TextColumn::make('init_inc')->label('Init(s)'),
            TextColumn::make('inc')->label('Inc(s)'),
            TextColumn::make('status')->badge()
                ->formatStateUsing(fn(string $state): string => $state==='0'?'Active':'Inactive')
                ->color(fn(string $state): string => $state==='0'?'success':'danger'),
        ])
        ->actions([EditAction::make(), DeleteAction::make()])
        ->defaultSort('prefix');
    }
}
