<?php
namespace App\Filament\Resources\Billing\OutboundRoutes;
use App\Filament\Resources\Billing\OutboundRoutes\Pages;
use App\Filament\Resources\Billing\OutboundRoutes\Schemas;
use App\Filament\Resources\Billing\OutboundRoutes\Tables;
use App\Models\Billing\OutboundRoute;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class OutboundRouteResource extends Resource {
    protected static ?string $model           = OutboundRoute::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-arrow-trending-up';
    protected static ?string $navigationLabel = 'Termination Rates';
    protected static ?int    $navigationSort  = 5;
    protected static ?string $modelLabel      = 'OutboundRoute';
    protected static ?string $pluralModelLabel = 'OutboundRoutes';
    public static function form(Form $form): Form { return Schemas\OutboundRouteForm::configure($form); }
    public static function table(Table $table): Table { return Tables\OutboundRoutesTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListOutboundRoutes::route('/'),
            'create' => Pages\CreateOutboundRoute::route('/create'),
            'edit'   => Pages\EditOutboundRoute::route('/{record}/edit'),
        ];
    }
}
