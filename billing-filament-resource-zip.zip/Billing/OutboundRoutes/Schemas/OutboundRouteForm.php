<?php
namespace App\Filament\Resources\Billing\OutboundRoutes\Schemas;
use App\Models\Billing\Trunk;
use App\Models\Billing\Pricelist;
use Filament\Forms\Form;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
class OutboundRouteForm {
    public static function configure(Form $form): Form {
        return $form->schema([
            Section::make('Route')->columns(3)->schema([
                Select::make('trunk_id')->label('Trunk')
                    ->options(fn() => Trunk::where('status',0)->pluck('name','id'))
                    ->required()->searchable(),
                TextInput::make('prefix')->required()->placeholder('880'),
                TextInput::make('comment')->label('Destination'),
                Select::make('pricelist_id')->label('Rate Plan')
                    ->options(fn() => Pricelist::where('status',0)->pluck('name','id'))
                    ->nullable()->searchable(),
                Select::make('status')->options([0=>'Active',1=>'Inactive'])->default(0),
            ]),
            Section::make('Billing')->columns(3)->schema([
                TextInput::make('cost')->label('Cost/Min ($)')->numeric()->default(0),
                TextInput::make('connectcost')->label('Connect Cost ($)')->numeric()->default(0),
                TextInput::make('init_inc')->label('Init (s)')->numeric()->default(60),
                TextInput::make('inc')->label('Inc (s)')->numeric()->default(1),
                TextInput::make('strip')->label('Strip Digits')->numeric()->default(0),
                TextInput::make('prepend')->label('Prepend')->placeholder('+880'),
                TextInput::make('precedence')->label('Priority')->numeric()->default(0),
            ]),
        ]);
    }
}
