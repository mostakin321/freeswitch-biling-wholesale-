<?php
namespace App\Filament\Resources\Billing\Ratedeck\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Filters\SelectFilter;
use Filament\Support\Enums\FontWeight;
class RatedeckTable {
    public static function configure(Table $table): Table {
        return $table->columns([
            TextColumn::make('reseller.company_name')->label('Reseller')->default('Admin')->badge()->color('purple'),
            TextColumn::make('prefix')->searchable()->sortable()->weight(FontWeight::Medium),
            TextColumn::make('destination')->searchable()->default('—'),
            TextColumn::make('cost')->label('Buy Cost/Min')->money('usd')->sortable()->color('danger'),
            TextColumn::make('init_inc')->label('Init(s)'),
            TextColumn::make('inc')->label('Inc(s)'),
            TextColumn::make('status')->badge()
                ->formatStateUsing(fn(string $state): string => $state==='0'?'Active':'Inactive')
                ->color(fn(string $state): string => $state==='0'?'success':'danger'),
        ])
        ->actions([EditAction::make(), DeleteAction::make()])
        ->defaultSort('prefix');
    }
}
