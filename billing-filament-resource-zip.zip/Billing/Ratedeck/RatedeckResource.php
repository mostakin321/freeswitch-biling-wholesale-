<?php
namespace App\Filament\Resources\Billing\Ratedeck;
use App\Models\Billing\Ratedeck;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class RatedeckResource extends Resource {
    protected static ?string $model          = Ratedeck::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-arrow-trending-down';
    protected static ?string $navigationLabel = 'Ratedeck (Buy Rates)';
    protected static ?int    $navigationSort  = 4;
    public static function form(Form $form): Form { return Schemas\RatedeckForm::configure($form); }
    public static function table(Table $table): Table { return Tables\RatedeckTable::configure($table); }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListRatedeck::route('/'),
            'create' => Pages\CreateRatedeck::route('/create'),
            'edit'   => Pages\EditRatedeck::route('/{record}/edit'),
        ];
    }
}
