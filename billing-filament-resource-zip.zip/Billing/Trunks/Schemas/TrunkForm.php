<?php

namespace App\Filament\Resources\Billing\Trunks\Schemas;

use App\Models\Billing\Account;
use App\Models\Billing\Trunk;
use App\Models\FusionPBX\Gateway;
use App\Services\FreeSwitchEsl;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Grid;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Illuminate\Support\HtmlString;

class TrunkForm
{
    public static function configure(Form $form): Form
    {
        return $form->schema([

            // ── Section 1: Identity ───────────────────────────────
            Section::make('Trunk Information')
                ->description('Basic trunk identification and provider linkage.')
                ->icon('heroicon-o-server')
                ->columns(3)
                ->schema([
                    TextInput::make('name')
                        ->label('Trunk Name')
                        ->required()
                        ->placeholder('BDWEB-Primary')
                        ->helperText('Name for identification (e.g. BDWEB-CLI-Primary)')
                        ->columnSpan(1),

                    // Provider = carrier billing account (type=3 in ASTPP)
                    Select::make('provider_id')
                        ->label('Provider / Carrier Account')
                        ->options(fn() => Account::where('type', 3)
                            ->where('status', 0)
                            ->where('deleted', 0)
                            ->get()
                            ->mapWithKeys(fn($a) => [
                                $a->id => $a->number . ' — ' . ($a->company_name ?: $a->first_name)
                            ]))
                        ->searchable()
                        ->nullable()
                        ->helperText('Carrier/provider account for cost tracking')
                        ->columnSpan(1),

                    Select::make('status')
                        ->options([0 => 'Active', 1 => 'Inactive'])
                        ->default(0)
                        ->required()
                        ->columnSpan(1),
                ]),

            // ── Section 2: Gateway / FreeSWITCH ──────────────────
            Section::make('FreeSWITCH Gateways')
                ->description('Primary gateway and failover chain. Calls try Primary → Failover #1 → Failover #2.')
                ->icon('heroicon-o-arrows-right-left')
                ->columns(3)
                ->schema([

                    // Primary Gateway
                    Select::make('gateway_id')
                        ->label('Primary Gateway')
                        ->options(fn() => Gateway::pluck('gateway', 'gateway_uuid'))
                        ->searchable()
                        ->live()
                        ->afterStateUpdated(function (Get $get, Set $set, ?string $state) {
                            if (!$state) return;
                            $gw = Gateway::where('gateway_uuid', $state)->first();
                            if ($gw) {
                                $set('gateway_name', $gw->gateway);
                                // Auto-fill SIP profile from gateway
                                if (!empty($gw->profile)) {
                                    $set('sip_profile', $gw->profile);
                                }
                            }
                        })
                        ->helperText('Main gateway to send calls through')
                        ->required(),

                    // Failover #1
                    Select::make('failover_gateway_id')
                        ->label('Failover Gateway #1')
                        ->options(fn() => Gateway::pluck('gateway', 'gateway_uuid'))
                        ->searchable()
                        ->nullable()
                        ->helperText('Used if primary gateway fails or is busy'),

                    // Failover #2
                    Select::make('failover_gateway_id1')
                        ->label('Failover Gateway #2')
                        ->options(fn() => Gateway::pluck('gateway', 'gateway_uuid'))
                        ->searchable()
                        ->nullable()
                        ->helperText('Third attempt if #1 also fails'),

                    TextInput::make('gateway_name')
                        ->label('Gateway Name (FreeSWITCH)')
                        ->placeholder('BDWEB')
                        ->helperText('Auto-filled from primary gateway selection. Must match FreeSWITCH gateway name exactly.')
                        ->readOnly(),

                    Select::make('sip_profile')
                        ->label('SIP Profile')
                        ->options([
                            'external' => 'external',
                            'internal' => 'internal',
                            'external-ipv6' => 'external-ipv6',
                        ])
                        ->default('external')
                        ->helperText('FreeSWITCH SIP profile to use'),

                    Select::make('sip_cid_type')
                        ->label('Remote ID / CallerID Type')
                        ->options([
                            'none'  => 'None (pass-through)',
                            'pid'   => 'P-Asserted-Identity',
                            'rpid'  => 'Remote-Party-ID',
                            'from'  => 'From Header',
                        ])
                        ->default('none')
                        ->helperText('How Caller ID appears in outbound SIP header'),
                ]),

            // ── Section 3: Digit Manipulation ────────────────────
            Section::make('Number Translation')
                ->description('Strip digits and add prefix/suffix before sending to carrier.')
                ->icon('heroicon-o-hashtag')
                ->columns(3)
                ->schema([
                    TextInput::make('strip_digit')
                        ->label('Strip Digits')
                        ->numeric()
                        ->default(0)
                        ->helperText('Remove N digits from start. e.g. 2 → 0088123456 becomes 88123456'),

                    TextInput::make('add_prefix')
                        ->label('Add Prefix')
                        ->placeholder('e.g. +88 or 880 or 9')
                        ->helperText('Prepend after stripping. Leave blank if no change needed.'),

                    TextInput::make('add_suffix')
                        ->label('Add Suffix')
                        ->placeholder('optional')
                        ->helperText('Append to end of number (rare)'),

                    TextInput::make('tech_prefix')
                        ->label('Tech Prefix')
                        ->placeholder('optional carrier auth prefix')
                        ->helperText('Carrier technical prefix for authentication'),

                    // Live preview of number translation
                    TextInput::make('sample_number')
                        ->label('Test Number')
                        ->placeholder('0088123456789')
                        ->live(debounce: 300)
                        ->dehydrated(false)
                        ->helperText('Type a number to preview the translation below'),

                    Placeholder::make('translation_preview')
                        ->label('Translation Result')
                        ->content(function (Get $get): HtmlString {
                            $sample  = $get('sample_number') ?: '0088123456789';
                            $strip   = (int)($get('strip_digit') ?? 0);
                            $prefix  = $get('add_prefix') ?? '';
                            $suffix  = $get('add_suffix') ?? '';
                            $tech    = $get('tech_prefix') ?? '';
                            $gwId    = $get('gateway_id') ?? 'GATEWAY_UUID';

                            $number = $strip > 0 ? substr($sample, $strip) : $sample;
                            $number = $prefix . $number . $suffix;

                            $bridge = "sofia/gateway/{$tech}{$gwId}/{$number}";

                            return new HtmlString(
                                '<div class="text-sm font-mono">' .
                                '<div><span class="text-gray-500">Input: </span><span class="text-blue-600">' . e($sample) . '</span></div>' .
                                '<div><span class="text-gray-500">Output: </span><span class="text-green-600 font-semibold">' . e($number) . '</span></div>' .
                                '<div class="mt-1"><span class="text-gray-500">Bridge: </span><span class="text-orange-600 text-xs">' . e($bridge) . '</span></div>' .
                                '</div>'
                            );
                        }),
                ]),

            // ── Section 4: Capacity & Routing ────────────────────
            Section::make('Capacity & Routing')
                ->description('Call limits, codecs and routing priority.')
                ->icon('heroicon-o-adjustments-horizontal')
                ->columns(3)
                ->schema([
                    TextInput::make('maxchannels')
                        ->label('Max Concurrent Calls')
                        ->numeric()
                        ->default(0)
                        ->helperText('0 = unlimited'),

                    TextInput::make('cps')
                        ->label('Max CPS')
                        ->numeric()
                        ->default(0)
                        ->helperText('Calls per second, 0 = unlimited'),

                    TextInput::make('leg_timeout')
                        ->label('Call Leg Timeout (sec)')
                        ->numeric()
                        ->default(30)
                        ->helperText('Ring timeout before trying failover'),

                    TextInput::make('precedence')
                        ->label('Priority / Precedence')
                        ->numeric()
                        ->default(1)
                        ->helperText('Lower number = higher priority in LCR routing'),

                    TextInput::make('codec')
                        ->label('Codec Preferences')
                        ->placeholder('PCMU,PCMA,G729')
                        ->helperText('Comma separated. Blank = use SIP profile defaults'),

                    Toggle::make('register')
                        ->label('Register to Provider')
                        ->default(true)
                        ->inline(false)
                        ->helperText('Whether FreeSWITCH registers to this gateway'),
                ]),

            // ── Section 5: Notes ──────────────────────────────────
            Section::make('Notes')
                ->collapsed()
                ->schema([
                    Textarea::make('notes')->rows(3)->columnSpanFull(),
                ]),
        ]);
    }
}
