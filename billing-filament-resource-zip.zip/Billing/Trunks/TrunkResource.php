<?php

namespace App\Filament\Resources\Billing\Trunks;

use App\Models\Billing\Trunk;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;

class TrunkResource extends Resource
{
    protected static ?string $model          = Trunk::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-server';
    protected static ?string $navigationLabel = 'Trunks';
    protected static ?int    $navigationSort  = 5;

    public static function form(Form $form): Form
    {
        return Schemas\TrunkForm::configure($form);
    }

    public static function table(Table $table): Table
    {
        return Tables\TrunksTable::configure($table);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListTrunks::route('/'),
            'create' => Pages\CreateTrunk::route('/create'),
            'edit'   => Pages\EditTrunk::route('/{record}/edit'),
        ];
    }
}
