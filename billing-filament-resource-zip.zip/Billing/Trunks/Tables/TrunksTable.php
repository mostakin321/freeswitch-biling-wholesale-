<?php

namespace App\Filament\Resources\Billing\Trunks\Tables;

use App\Models\Billing\OutboundRoute;
use App\Models\FusionPBX\Gateway;
use App\Services\FreeSwitchEsl;
use Filament\Notifications\Notification;
use Filament\Support\Enums\FontWeight;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Cache;

class TrunksTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('Trunk Name')
                    ->searchable()
                    ->sortable()
                    ->weight(FontWeight::Bold),

                // Provider carrier account
                TextColumn::make('provider.number')
                    ->label('Provider')
                    ->searchable()
                    ->default('—')
                    ->badge()
                    ->color('purple'),

                // Primary gateway name from FusionPBX
                TextColumn::make('gateway_name')
                    ->label('Primary Gateway')
                    ->badge()
                    ->color('info')
                    ->formatStateUsing(fn($state) => $state ?: '—'),

                // Failover gateways - show as compact names
                TextColumn::make('failover_gateway_id')
                    ->label('Failover #1')
                    ->formatStateUsing(fn($state): string =>
                        empty($state) ? '—' :
                        (\App\Models\FusionPBX\Gateway::where('gateway_uuid',$state)->value('gateway') ?? substr($state,0,8).'…')
                    )
                    ->default('—')
                    ->color('gray'),

                TextColumn::make('failover_gateway_id1')
                    ->label('Failover #2')
                    ->formatStateUsing(fn($state): string =>
                        empty($state) ? '—' :
                        (\App\Models\FusionPBX\Gateway::where('gateway_uuid',$state)->value('gateway') ?? substr($state,0,8).'…')
                    )
                    ->default('—')
                    ->color('gray')
                    ->toggleable(isToggledHiddenByDefault: true),

                // Live registration status from FreeSWITCH
                TextColumn::make('reg_status')
                    ->label('Reg. Status')
                    ->badge()
                    ->state(function ($record): string {
                        if (empty($record->gateway_id)) return 'NO GW';
                        $all = Cache::remember('fs_gateway_statuses', 15, function () {
                            $r = FreeSwitchEsl::run('sofia status');
                            if (!$r['ok']) return [];
                            $statuses = [];
                            foreach (explode("\n", $r['output']) as $line) {
                                if (preg_match('/external::([0-9a-f\-]{36})\s+gateway\s+\S+\s+(REGED|NOREG|FAILED|TRYING|EXPIRED)/i', $line, $m)) {
                                    $statuses[strtolower($m[1])] = strtoupper($m[2]);
                                }
                            }
                            return $statuses;
                        });
                        return $all[strtolower($record->gateway_id)] ?? 'UNKNOWN';
                    })
                    ->color(fn(string $state): string => match($state) {
                        'REGED'  => 'success',
                        'TRYING' => 'warning',
                        'FAILED','EXPIRED' => 'danger',
                        'NOREG'  => 'gray',
                        default  => 'gray',
                    }),

                // Rate count = how many outbound_routes use this trunk
                TextColumn::make('outbound_routes_count')
                    ->label('Rate Count')
                    ->counts('outboundRoutes')
                    ->badge()
                    ->color('warning'),

                TextColumn::make('maxchannels')
                    ->label('Max CC')
                    ->formatStateUsing(fn($state) => $state > 0 ? $state : '∞'),

                TextColumn::make('cps')
                    ->label('CPS')
                    ->formatStateUsing(fn($state) => $state > 0 ? $state : '∞'),

                TextColumn::make('codec')
                    ->label('Codecs')
                    ->default('—')
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('precedence')
                    ->label('Priority')
                    ->sortable()
                    ->badge()
                    ->color('gray'),

                TextColumn::make('sip_cid_type')
                    ->label('CID Type')
                    ->badge()
                    ->color('gray')
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('creation_date')
                    ->label('Created')
                    ->dateTime('M j, Y')
                    ->sortable()
                    ->color('gray')
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('last_modified_date')
                    ->label('Modified')
                    ->dateTime('M j, Y H:i')
                    ->sortable()
                    ->color('gray')
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('status')
                    ->badge()
                    ->formatStateUsing(fn(string $state): string => match((int)$state) {
                        0 => 'Active', 1 => 'Inactive', 2 => 'Deleted', default => '?'
                    })
                    ->color(fn(string $state): string => match((int)$state) {
                        0 => 'success', 1 => 'warning', 2 => 'danger', default => 'gray'
                    }),
            ])
            ->filters([
                SelectFilter::make('status')
                    ->options([0 => 'Active', 1 => 'Inactive']),
            ])
            ->actions([
                // Resync gateway registration
                Action::make('resync')
                    ->label('Resync')
                    ->icon('heroicon-o-arrow-path')
                    ->color('warning')
                    ->tooltip('Force re-registration with provider')
                    ->action(function ($record) {
                        Cache::forget('fs_gateway_statuses');
                        $gwId = $record->gateway_id;
                        if (!$gwId) return;

                        $r = FreeSwitchEsl::run("sofia profile external resync external::{$gwId}");

                        Notification::make()
                            ->title($r['ok'] ? 'Resync sent' : 'Resync failed')
                            ->body($r['ok']
                                ? "Resync sent to gateway {$record->gateway_name}"
                                : ($r['error'] ?? 'ESL error'))
                            ->status($r['ok'] ? 'success' : 'warning')
                            ->send();
                    }),

                ActionGroup::make([
                    EditAction::make(),

                    // View related outbound routes
                    Action::make('view_rates')
                        ->label('View Rates')
                        ->icon('heroicon-o-currency-dollar')
                        ->color('info')
                        ->url(fn($record) =>
                            '/admin/billing/outbound-routes/outbound-routes?tableFilters[trunk_id][value]=' . $record->id
                        ),

                    DeleteAction::make()
                        ->before(function ($record) {
                            // Match ASTPP: delete outbound_routes when trunk is deleted
                            OutboundRoute::where('trunk_id', $record->id)->delete();
                            Notification::make()
                                ->title('Trunk deleted')
                                ->body('All associated outbound routes have also been removed.')
                                ->warning()
                                ->send();
                        }),
                ])->label('More'),
            ])
            ->headerActions([
                Action::make('refresh_status')
                    ->label('Refresh Status')
                    ->icon('heroicon-o-arrow-path')
                    ->color('gray')
                    ->action(function () {
                        Cache::forget('fs_gateway_statuses');
                        Notification::make()
                            ->title('Status refreshed')
                            ->body('Gateway registration statuses updated from FreeSWITCH.')
                            ->success()
                            ->send();
                    }),
            ])
            ->defaultSort('precedence')
            ->poll('30s');
    }
}
