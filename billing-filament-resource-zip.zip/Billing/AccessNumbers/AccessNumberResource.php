<?php
namespace App\Filament\Resources\Billing\AccessNumbers;
use App\Models\Billing\AccessNumber;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class AccessNumberResource extends Resource {
    protected static ?string $model           = AccessNumber::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-phone-arrow-down-left';
    protected static ?string $navigationLabel = 'Access Numbers';
    protected static ?int    $navigationSort  = 14;
    protected static ?string $modelLabel      = 'Access Number';
    protected static ?string $pluralModelLabel = 'Access Numbers';
    public static function form(Form $form): Form { return Schemas\AccessNumberForm::configure($form); }
    public static function table(Table $table): Table { return Tables\AccessNumbersTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListAccessNumbers::route('/'),
            'create' => Pages\CreateAccessNumber::route('/create'),
            'edit'   => Pages\EditAccessNumber::route('/{record}/edit'),
        ];
    }
}
