<?php
namespace App\Filament\Resources\Billing\Pricelists\Tables;

use App\Models\Billing\Route;
use Filament\Support\Enums\FontWeight;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class PricelistsTable
{
    public static function configure(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')
                ->searchable()->sortable()->weight(FontWeight::Bold),

            TextColumn::make('reseller.company_name')
                ->label('Reseller')->default('Admin')
                ->badge()->color('purple'),

            TextColumn::make('routing_type')
                ->label('Routing')->badge()
                ->formatStateUsing(fn($state): string => match((int)$state) {
                    0 => 'LCR', 1 => 'Priority', default => '?'
                })
                ->color(fn($state): string => (int)$state === 0 ? 'info' : 'warning'),

            TextColumn::make('markup')
                ->label('Markup %')->default('0'),

            TextColumn::make('initially_increment')
                ->label('Init(s)'),

            TextColumn::make('inc')
                ->label('Inc(s)'),

            // Count of origination rates
            TextColumn::make('routes_count')
                ->label('Rates')
                ->state(fn($record) => Route::where('pricelist_id', $record->id)->count())
                ->badge()->color('info'),

            TextColumn::make('status')->badge()
                ->formatStateUsing(fn(string $state): string => $state==='0'?'Active':'Inactive')
                ->color(fn(string $state): string => $state==='0'?'success':'danger'),
        ])
        ->filters([
            SelectFilter::make('status')
                ->options([0 => 'Active', 1 => 'Inactive']),
        ])
        ->actions([
            EditAction::make(),
            Action::make('view_rates')
                ->label('Rates')
                ->icon('heroicon-o-currency-dollar')
                ->color('info')
                ->url(fn($record) =>
                    '/admin/billing/origination-rates/origination-rates?tableFilters[pricelist_id][value]=' . $record->id
                ),
            DeleteAction::make(),
        ])
        ->defaultSort('name');
    }
}
