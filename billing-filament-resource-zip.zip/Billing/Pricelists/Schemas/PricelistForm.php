<?php
namespace App\Filament\Resources\Billing\Pricelists\Schemas;

use App\Models\Billing\Account;
use App\Models\Billing\Pricelist;
use App\Models\Billing\Route;
use Carbon\Carbon;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Tabs;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Form;
use Filament\Forms\Get;

class PricelistForm
{
    public static function configure(Form $form): Form
    {
        return $form->schema([
            Tabs::make('Rate Group')->columnSpanFull()->tabs([

                Tabs\Tab::make('Basic Information')
                    ->icon('heroicon-o-document-text')
                    ->schema([
                        Section::make('Rate Group Details')
                            ->description('Define the rate group name, reseller ownership and routing strategy.')
                            ->icon('heroicon-o-folder')
                            ->columns(3)
                            ->schema([
                                TextInput::make('name')
                                    ->label('Name')
                                    ->required()->placeholder('BD-CLI-Tier1')
                                    ->helperText('Name of Rate Group for identification.'),

                                Select::make('reseller_id')
                                    ->label('Reseller')
                                    ->options(fn() => collect([0 => 'Admin (Default)'])
                                        ->merge(Account::where('type', 3)
                                            ->where('status', 0)
                                            ->pluck('company_name', 'id')))
                                    ->default(0)->searchable()
                                    ->helperText('Reseller who owns this rate group.'),

                                Select::make('status')
                                    ->options([0 => 'Active', 1 => 'Inactive'])
                                    ->default(0)
                                    ->helperText('Status of rate group (Active/Inactive).'),

                                TextInput::make('routing_prefix')
                                    ->label('Routing Prefix')
                                    ->placeholder('optional')
                                    ->helperText('Prefix-based routing. Calls matching this prefix use this rate group.'),

                                Select::make('pricelist_id_admin')
                                    ->label('Admin Rate Group (for prefix routing)')
                                    ->options(fn() => collect([0 => 'None'])
                                        ->merge(Pricelist::where('status', 0)
                                            ->where('reseller_id', 0)
                                            ->pluck('name', 'id')))
                                    ->default(0)->searchable()
                                    ->helperText('Admin rate group used when routing prefix is configured.'),
                            ]),
                    ]),

                Tabs\Tab::make('Billing Settings')
                    ->icon('heroicon-o-currency-dollar')
                    ->schema([
                        Section::make('Billing Configuration')
                            ->description('Markup, increment and routing type for calls under this rate group.')
                            ->icon('heroicon-o-calculator')
                            ->columns(3)
                            ->schema([
                                TextInput::make('markup')
                                    ->label('Markup (%)')
                                    ->default('0')
                                    ->helperText('Extra % charge on call cost. e.g. 10 = customer pays 10% more.'),

                                TextInput::make('initially_increment')
                                    ->label('Initial Increment (sec)')
                                    ->numeric()->default(60)
                                    ->helperText('Initial billing block for calls. Used when rate has no init_inc.'),

                                TextInput::make('inc')
                                    ->label('Increment (sec)')
                                    ->numeric()->default(1)
                                    ->helperText('Billing increment. 60 = per minute, 1 = per second.'),

                                Select::make('routing_type')
                                    ->label('Routing Type')
                                    ->options([
                                        0 => 'LCR (Least Cost Routing)',
                                        1 => 'Priority Routing',
                                    ])
                                    ->default(0)
                                    ->helperText('LCR routes by lowest cost; Priority forces trunk order.'),
                            ]),
                    ]),
            ]),

            Section::make('Record Info')
                ->icon('heroicon-o-information-circle')
                ->collapsed()->columns(3)
                ->schema([
                    Placeholder::make('rates_count')->label('Origination Rates')
                        ->content(fn($record) => $record
                            ? Route::where('pricelist_id', $record->id)->count() . ' rates'
                            : '—'),
                    Placeholder::make('created_info')->label('Created')
                        ->content(fn($record) => $record?->creation_date
                            ? Carbon::parse($record->creation_date)->format('M j, Y H:i') : '—'),
                    Placeholder::make('modified_info')->label('Modified')
                        ->content(fn($record) => $record?->last_modified_date
                            ? Carbon::parse($record->last_modified_date)->diffForHumans() : '—'),
                ])->visibleOn('edit'),
        ]);
    }
}
