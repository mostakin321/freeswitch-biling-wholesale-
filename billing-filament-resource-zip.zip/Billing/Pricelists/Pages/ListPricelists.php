<?php
namespace App\Filament\Resources\Billing\Pricelists\Pages;
use App\Filament\Resources\Billing\Pricelists\PricelistResource;
use Filament\Resources\Pages\ListRecords;
class ListPricelists extends ListRecords {
    protected static string $resource = PricelistResource::class;
}
