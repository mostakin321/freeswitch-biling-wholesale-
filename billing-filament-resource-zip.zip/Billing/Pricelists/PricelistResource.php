<?php
namespace App\Filament\Resources\Billing\Pricelists;
use App\Models\Billing\Pricelist;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class PricelistResource extends Resource {
    protected static ?string $model          = Pricelist::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'Rate Groups';
    protected static ?int    $navigationSort  = 2;
    public static function form(Form $form): Form { return Schemas\PricelistForm::configure($form); }
    public static function table(Table $table): Table { return Tables\PricelistsTable::configure($table); }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListPricelists::route('/'),
            'create' => Pages\CreatePricelist::route('/create'),
            'edit'   => Pages\EditPricelist::route('/{record}/edit'),
        ];
    }
}
