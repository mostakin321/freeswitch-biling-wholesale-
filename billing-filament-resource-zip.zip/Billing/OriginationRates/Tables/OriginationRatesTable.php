<?php
namespace App\Filament\Resources\Billing\OriginationRates\Tables;

use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Filters\SelectFilter;
use Filament\Support\Enums\FontWeight;
use Illuminate\Support\Facades\DB;

class OriginationRatesTable
{
    public static function configure(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('pricelist.name')
                ->label('Rate Plan')->badge()->color('info'),
            TextColumn::make('pattern')
                ->label('Prefix')->searchable()->sortable()
                ->weight(FontWeight::Medium),
            TextColumn::make('comment')
                ->label('Destination')->searchable()->default('—'),
            TextColumn::make('country_id')
                ->label('Country')
                ->formatStateUsing(fn($state) => $state
                    ? DB::table('countrycode')->where('id', $state)->value('country') ?? '—'
                    : '—')
                ->badge()->color('gray'),
            TextColumn::make('call_type')
                ->label('Type')
                ->formatStateUsing(fn($state) => $state
                    ? DB::table('calltype')->where('id', $state)->value('call_type') ?? $state
                    : '—')
                ->badge()->color('purple'),
            TextColumn::make('cost')
                ->label('Cost/Min')->money('usd')->sortable(),
            TextColumn::make('connectcost')
                ->label('Connect')->money('usd'),
            TextColumn::make('init_inc')->label('Init(s)'),
            TextColumn::make('inc')->label('Inc(s)'),
            TextColumn::make('precedence')->label('Pri')->sortable(),
            TextColumn::make('status')->badge()
                ->formatStateUsing(fn(string $state): string => $state==='0'?'Active':'Inactive')
                ->color(fn(string $state): string => $state==='0'?'success':'danger'),
        ])
        ->filters([
            SelectFilter::make('pricelist_id')
                ->label('Rate Plan')
                ->relationship('pricelist', 'name'),
            SelectFilter::make('status')
                ->options([0 => 'Active', 1 => 'Inactive']),
        ])
        ->actions([EditAction::make(), DeleteAction::make()])
        ->defaultSort('pattern');
    }
}
