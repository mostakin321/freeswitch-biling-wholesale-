<?php
namespace App\Filament\Resources\Billing\OriginationRates;

use App\Models\Billing\Route;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;

class OriginationRateResource extends Resource
{
    protected static ?string $model           = Route::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-arrow-trending-up';
    protected static ?string $navigationLabel = 'Origination Rates';
    protected static ?int    $navigationSort  = 3;
    protected static ?string $modelLabel      = 'Origination Rate';
    protected static ?string $pluralModelLabel = 'Origination Rates';

    public static function form(Form $form): Form
    {
        return Schemas\OriginationRateForm::configure($form);
    }

    public static function table(Table $table): Table
    {
        return Tables\OriginationRatesTable::configure($table);
    }

    public static function getRelations(): array { return []; }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListOriginationRates::route('/'),
            'create' => Pages\CreateOriginationRate::route('/create'),
            'edit'   => Pages\EditOriginationRate::route('/{record}/edit'),
        ];
    }
}
