<?php
namespace App\Filament\Resources\Billing\Orders;
use App\Models\Billing\Order;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class OrderResource extends Resource {
    protected static ?string $model           = Order::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-shopping-cart';
    protected static ?string $navigationLabel = 'Orders';
    protected static ?int    $navigationSort  = 13;
    protected static ?string $modelLabel      = 'Order';
    protected static ?string $pluralModelLabel = 'Orders';
    public static function form(Form $form): Form { return Schemas\OrderForm::configure($form); }
    public static function table(Table $table): Table { return Tables\OrdersTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListOrders::route('/'),
            'create' => Pages\CreateOrder::route('/create'),
            'edit'   => Pages\EditOrder::route('/{record}/edit'),
        ];
    }
}
