<?php
namespace App\Filament\Resources\Billing\Rates;
use App\Models\Billing\Rate;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class RateResource extends Resource {
    protected static ?string $model          = Rate::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-currency-dollar';
    protected static ?string $navigationLabel = 'Rates';
    protected static ?int    $navigationSort  = 2;
    public static function form(Form $form): Form { return Schemas\RateForm::configure($form); }
    public static function table(Table $table): Table { return Tables\RatesTable::configure($table); }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListRates::route('/'),
            'create' => Pages\CreateRate::route('/create'),
            'edit'   => Pages\EditRate::route('/{record}/edit'),
        ];
    }
}
