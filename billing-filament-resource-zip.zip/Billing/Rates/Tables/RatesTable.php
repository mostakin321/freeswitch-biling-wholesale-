<?php
namespace App\Filament\Resources\Billing\Rates\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Filters\SelectFilter;
use Filament\Support\Enums\FontWeight;

class RatesTable
{
    public static function configure(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('pricelist.name')->label('Pricelist')->badge()->color('info'),
            TextColumn::make('prefix')->searchable()->sortable()->weight(FontWeight::Medium),
            TextColumn::make('destination')->searchable(),
            TextColumn::make('rate')->label('Rate/Min')->money('usd')->sortable(),
            TextColumn::make('connectcost')->label('Connect')->money('usd'),
            TextColumn::make('initblock')->label('Init(s)'),
            TextColumn::make('increment')->label('Inc(s)'),
            TextColumn::make('status')->badge()
                ->formatStateUsing(fn(string $state): string => $state === '0' ? 'Active' : 'Inactive')
                ->color(fn(string $state): string => $state === '0' ? 'success' : 'danger'),
        ])
        ->filters([
            SelectFilter::make('pricelist_id')->relationship('pricelist', 'name'),
        ])
        ->actions([EditAction::make(), DeleteAction::make()])
        ->defaultSort('prefix');
    }
}
