<?php
namespace App\Filament\Resources\Billing\Rates\Schemas;

use App\Models\Billing\Pricelist;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Illuminate\Support\Facades\DB;

class RateForm
{
    public static function configure(Form $form): Form
    {
        return $form->schema([

            Section::make('Rate Information')
                ->description('Origination rate — charged to customer based on their pricelist.')
                ->icon('heroicon-o-currency-dollar')
                ->columns(3)
                ->schema([
                    // Reseller filter
                    Select::make('reseller_id')
                        ->label('Reseller')
                        ->options(fn() => collect([0 => 'Admin (Default)'])
                            ->merge(\App\Models\Billing\Account::where('type', 3)
                                ->where('status', 0)
                                ->pluck('company_name', 'id')))
                        ->default(0)
                        ->live()
                        ->searchable()
                        ->helperText('Reseller who owns this rate group'),

                    // Rate Group (pricelist) — filtered by reseller
                    Select::make('pricelist_id')
                        ->label('Rate Group / Plan')
                        ->options(fn(Get $get) => Pricelist::where('status', 0)
                            ->when($get('reseller_id'), fn($q, $v) =>
                                $v > 0 ? $q->where('reseller_id', $v) : $q
                            )->pluck('country', 'id'))
                        ->required()
                        ->searchable()
                        ->helperText('Rate group this prefix belongs to'),

                    // Code/Prefix
                    TextInput::make('prefix')
                        ->label('Code / Prefix')
                        ->required()
                        ->placeholder('880')
                        ->live(debounce: 500)
                        ->afterStateUpdated(function (Get $get, Set $set, ?string $state) {
                            if (!$state) return;
                            for ($i = strlen($state); $i >= 1; $i--) {
                                $d = DB::table('prefix_destinations')
                                    ->where('prefix', substr($state, 0, $i))->first();
                                if ($d) {
                                    $set('destination', $d->destination);
                                    $set('country_id',  $d->country_code ?? '');
                                    break;
                                }
                            }
                        })
                        ->helperText('Prefix e.g. 880, 8801, 91'),

                    TextInput::make('destination')
                        ->label('Destination')
                        ->placeholder('Auto-filled from prefix')
                        ->helperText('Description e.g. Bangladesh Mobile'),

                    // Call type from calltype table
                    Select::make('traffic_type')
                        ->label('Call Type')
                        ->options(fn() => DB::table('calltype')
                            ->where('status', 0)->pluck('call_type', 'id'))
                        ->default('cli')
                        ->helperText('Traffic type: CLI, Non-CLI, IP Phone, etc.'),

                    Select::make('country_id')
                        ->label('Country')
                        ->options(fn() => DB::table('countrycode')
                            ->where('status', 0)->orderBy('name')->pluck('country', 'id'))
                        ->searchable()
                        ->nullable()
                        ->helperText('Country for this prefix'),

                    Select::make('status')
                        ->options([0 => 'Active', 1 => 'Inactive'])
                        ->default(0),
                ]),

            Section::make('Billing Information')
                ->icon('heroicon-o-calculator')
                ->columns(3)
                ->schema([
                    TextInput::make('connectcost')
                        ->label('Connect Cost ($)')
                        ->numeric()
                        ->default(0)
                        ->helperText('Connection fee to charge minimum when call connects'),

                    TextInput::make('includedseconds')
                        ->label('Included Seconds')
                        ->numeric()
                        ->default(0)
                        ->helperText('Free seconds per call, not billed'),

                    TextInput::make('rate')
                        ->label('Cost / Min ($)')
                        ->numeric()
                        ->required()
                        ->default(0)
                        ->helperText('Cost per minute to charge customer'),

                    TextInput::make('initblock')
                        ->label('Initial Increment (sec)')
                        ->numeric()
                        ->default(60)
                        ->helperText('Very first billing increment. e.g. 60 = first minute minimum'),

                    TextInput::make('increment')
                        ->label('Increment (sec)')
                        ->numeric()
                        ->default(1)
                        ->helperText('Subsequent billing increment. e.g. 60 = per minute, 1 = per second, 6 = per 6s'),

                    DateTimePicker::make('effective_date')
                        ->label('Effective Date')
                        ->nullable()
                        ->helperText('Rate applies from this date/time'),
                ]),
        ]);
    }
}
