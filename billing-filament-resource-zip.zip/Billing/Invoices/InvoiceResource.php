<?php
namespace App\Filament\Resources\Billing\Invoices;
use App\Models\Billing\Invoice;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class InvoiceResource extends Resource {
    protected static ?string $model           = Invoice::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-document-currency-dollar';
    protected static ?string $navigationLabel = 'Invoices';
    protected static ?int    $navigationSort  = 12;
    protected static ?string $modelLabel      = 'Invoice';
    protected static ?string $pluralModelLabel = 'Invoices';
    public static function form(Form $form): Form { return Schemas\InvoiceForm::configure($form); }
    public static function table(Table $table): Table { return Tables\InvoicesTable::configure($table); }
    public static function canCreate(): bool { return false; }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index' => Pages\ListInvoices::route('/'),
            'edit'  => Pages\EditInvoice::route('/{record}/edit'),
        ];
    }
}
