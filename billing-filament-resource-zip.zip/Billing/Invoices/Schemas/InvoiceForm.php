<?php
namespace App\Filament\Resources\Billing\Invoices\Schemas;
use Carbon\Carbon;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Section;
use Filament\Forms\Form;
class InvoiceForm {
    public static function configure(Form $form): Form {
        return $form->schema([
            Section::make('Invoice Details')->columns(3)->schema([
                Placeholder::make('number')->label('Invoice Number')
                    ->content(fn($record) => ($record?->prefix ?? '')  . ($record?->number ?? '—')),
                Placeholder::make('accountid')->label('Account ID')
                    ->content(fn($record) => $record?->accountid ?? '—'),
                Placeholder::make('status_info')->label('Status')
                    ->content(fn($record) => match((int)($record?->status ?? 0)){
                        0=>'Paid', 1=>'Unpaid', 2=>'Overdue', default=>'Unknown'
                    }),
                Placeholder::make('from_date')->label('From Date')
                    ->content(fn($record) => $record?->from_date
                        ? Carbon::parse($record->from_date)->format('M j, Y') : '—'),
                Placeholder::make('to_date')->label('To Date')
                    ->content(fn($record) => $record?->to_date
                        ? Carbon::parse($record->to_date)->format('M j, Y') : '—'),
                Placeholder::make('due_date')->label('Due Date')
                    ->content(fn($record) => $record?->due_date
                        ? Carbon::parse($record->due_date)->format('M j, Y') : '—'),
            ]),
        ]);
    }
}
