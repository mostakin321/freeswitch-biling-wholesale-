<?php
namespace App\Filament\Resources\Billing\Cdrs\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\Filter;
use Filament\Forms\Components\DatePicker;
use Filament\Support\Enums\FontWeight;

class CdrsTable
{
    public static function configure(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('account_number')->label('Account')->searchable()->weight(FontWeight::Medium),
            TextColumn::make('caller_number')->label('From')->searchable(),
            TextColumn::make('destination_number')->label('To')->searchable(),
            TextColumn::make('billsec')->label('Sec')->sortable(),
            TextColumn::make('billed_seconds')->label('Billed')->sortable(),
            TextColumn::make('sell_rate')->label('Rate/Min')->money('usd'),
            TextColumn::make('call_cost')->label('Cost')->money('usd')->sortable()->color('danger'),
            TextColumn::make('status')->badge()
                ->color(fn(string $state): string => $state === 'ANSWERED' ? 'success' : 'danger'),
            TextColumn::make('start_time')->label('Start')->dateTime('M j H:i')->sortable(),
        ])
        ->filters([
            SelectFilter::make('status')
                ->options(['ANSWERED' => 'Answered', 'NO_ANSWER' => 'No Answer']),
            Filter::make('start_time')
                ->form([
                    DatePicker::make('from'),
                    DatePicker::make('until'),
                ])
                ->query(fn($query, array $data) => $query
                    ->when($data['from'],  fn($q, $v) => $q->whereDate('start_time', '>=', $v))
                    ->when($data['until'], fn($q, $v) => $q->whereDate('start_time', '<=', $v))
                ),
        ])
        ->defaultSort('start_time', 'desc');
    }
}
