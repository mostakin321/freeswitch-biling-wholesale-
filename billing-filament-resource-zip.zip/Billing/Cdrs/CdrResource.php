<?php
namespace App\Filament\Resources\Billing\Cdrs;
use App\Models\Billing\BillingCdr;
use App\Services\Billing\UserBillingService;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class CdrResource extends Resource {
    protected static ?string $model          = BillingCdr::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-phone';
    protected static ?string $navigationLabel = 'Call Records';
    protected static ?int    $navigationSort  = 3;
    public static function form(Form $form): Form { return $form->schema([]); }
    public static function table(Table $table): Table { return Tables\CdrsTable::configure($table); }
    public static function canCreate(): bool { return false; }
    public static function getEloquentQuery(): \Illuminate\Database\Eloquent\Builder {
        $q    = parent::getEloquentQuery();
        $user = auth()->user();
        $scope = app(UserBillingService::class)->scopeFor($user);
        return match($scope['scope']) {
            'domain' => $q->where('reseller_id', $scope['reseller_id'] ?? 0),
            'self'   => $q->where('account_id',  $scope['account_id']  ?? 0),
            default  => $q,
        };
    }
    public static function getPages(): array {
        return ['index' => Pages\ListCdrs::route('/')];
    }
}
