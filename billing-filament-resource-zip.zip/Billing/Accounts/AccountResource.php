<?php

namespace App\Filament\Resources\Billing\Accounts;

use App\Models\Billing\Account;
use App\Services\Billing\UserBillingService;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;

class AccountResource extends Resource
{
    protected static ?string $model          = Account::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-users';
    protected static ?string $navigationLabel = 'Accounts';
    protected static ?int    $navigationSort  = 1;

    public static function form(Form $form): Form
    {
        return Schemas\AccountForm::configure($form);
    }

    public static function table(Table $table): Table
    {
        return Tables\AccountsTable::configure($table);
    }

    public static function getEloquentQuery(): \Illuminate\Database\Eloquent\Builder
    {
        $q = parent::getEloquentQuery()->where('deleted', 0);
        return app(UserBillingService::class)->applyScope($q, auth()->user());
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListAccounts::route('/'),
            'create' => Pages\CreateAccount::route('/create'),
            'edit'   => Pages\EditAccount::route('/{record}/edit'),
        ];
    }
}
