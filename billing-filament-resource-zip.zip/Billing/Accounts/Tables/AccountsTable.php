<?php
namespace App\Filament\Resources\Billing\Accounts\Tables;

use App\Models\Billing\Account;
use App\Models\Billing\BillingTransaction;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Filters\SelectFilter;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Notifications\Notification;
use Filament\Support\Enums\FontWeight;
use Illuminate\Support\Facades\DB;

class AccountsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('number')
                    ->label('Account')
                    ->searchable()->sortable()
                    ->weight(FontWeight::Medium),

                TextColumn::make('company_name')
                    ->label('Company')
                    ->searchable()->default('—'),

                TextColumn::make('type')
                    ->label('Type')
                    ->badge()
                    ->formatStateUsing(fn(string $state): string => match((int)$state) {
                        -1 => 'Admin', 3 => 'Reseller', 0 => 'Customer', default => '?'
                    })
                    ->color(fn(string $state): string => match((int)$state) {
                        -1 => 'danger', 3 => 'warning', 0 => 'success', default => 'gray'
                    }),

                // Balance with color: green=positive, red=zero/negative
                TextColumn::make('balance')
                    ->money('usd')->sortable()
                    ->color(fn($record): string =>
                        (float)$record->balance > 0 ? 'success' : 'danger'
                    )
                    ->weight(FontWeight::Bold),

                TextColumn::make('credit_limit')
                    ->label('Credit')
                    ->money('usd'),

                TextColumn::make('pricelist.name')
                    ->label('Rate Plan')
                    ->badge()->color('info'),

                TextColumn::make('reseller.company_name')
                    ->label('Reseller')
                    ->default('—')->color('gray'),

                TextColumn::make('extension')->default('—'),
                TextColumn::make('fx_group')->label('FX Group')->badge()->color('gray'),
            ])
            ->filters([
                SelectFilter::make('type')
                    ->options([-1 => 'Admin', 3 => 'Reseller', 0 => 'Customer']),
                SelectFilter::make('status')
                    ->options([0 => 'Active', 1 => 'Inactive']),
            ])
            ->actions([
                // TopUp action — primary action
                Action::make('topup')
                    ->label('Top Up')
                    ->icon('heroicon-o-plus-circle')
                    ->color('success')
                    ->form([
                        TextInput::make('amount')
                            ->label('Amount ($)')
                            ->numeric()
                            ->required()
                            ->minValue(0.01)
                            ->placeholder('10.00')
                            ->helperText('Current balance: $' . ''),

                        Select::make('type')
                            ->label('Transaction Type')
                            ->options([
                                'topup'      => 'Top Up (cash)',
                                'credit'     => 'Credit (free)',
                                'adjustment' => 'Manual Adjustment',
                                'refund'     => 'Refund',
                                'bonus'      => 'Bonus',
                            ])
                            ->default('topup')
                            ->required(),

                        TextInput::make('description')
                            ->label('Note')
                            ->placeholder('Bank transfer ref #12345')
                            ->maxLength(256),
                    ])
                    ->action(function (array $data, Account $record): void {
                        $amount = (float) $data['amount'];
                        $balanceBefore = (float) $record->balance;
                        $balanceAfter  = $balanceBefore + $amount;

                        DB::transaction(function () use ($record, $data, $amount, $balanceBefore, $balanceAfter) {
                            $record->update(['balance' => $balanceAfter]);

                            BillingTransaction::create([
                                'account_id'     => $record->id,
                                'type'           => $data['type'],
                                'amount'         => $amount,
                                'balance_before' => $balanceBefore,
                                'balance_after'  => $balanceAfter,
                                'description'    => $data['description'] ?? 'Manual top-up',
                                'reference_type' => $data['type'],
                                'created_at'     => now(),
                            ]);
                        });

                        Notification::make()
                            ->title('Balance Updated')
                            ->body(
                                "Account: {$record->number}\n" .
                                "Added: \${$amount}\n" .
                                "New Balance: \${$balanceAfter}"
                            )
                            ->success()
                            ->send();
                    })
                    ->requiresConfirmation()
                    ->modalHeading(fn(Account $record) => "Top Up: {$record->number}")
                    ->modalDescription(fn(Account $record) =>
                        "Current balance: $" . number_format((float)$record->balance, 5)
                    ),

                // Deduct action
                Action::make('deduct')
                    ->label('Deduct')
                    ->icon('heroicon-o-minus-circle')
                    ->color('warning')
                    ->form([
                        TextInput::make('amount')->label('Amount ($)')->numeric()->required()->minValue(0.01),
                        Select::make('type')->options([
                            'call'       => 'Call charge',
                            'adjustment' => 'Manual Adjustment',
                            'charge'     => 'Service Charge',
                        ])->default('adjustment')->required(),
                        TextInput::make('description')->label('Note')->placeholder('Monthly DID fee')->maxLength(256),
                    ])
                    ->action(function (array $data, Account $record): void {
                        $amount = (float) $data['amount'];
                        $balanceBefore = (float) $record->balance;
                        $balanceAfter  = $balanceBefore - $amount;

                        DB::transaction(function () use ($record, $data, $amount, $balanceBefore, $balanceAfter) {
                            $record->update(['balance' => $balanceAfter]);
                            BillingTransaction::create([
                                'account_id'     => $record->id,
                                'type'           => $data['type'],
                                'amount'         => -$amount,
                                'balance_before' => $balanceBefore,
                                'balance_after'  => $balanceAfter,
                                'description'    => $data['description'] ?? 'Manual deduction',
                                'reference_type' => $data['type'],
                                'created_at'     => now(),
                            ]);
                        });

                        Notification::make()
                            ->title('Balance Deducted')
                            ->body("Deducted \${$amount} from {$record->number}. New balance: \${$balanceAfter}")
                            ->warning()
                            ->send();
                    })
                    ->requiresConfirmation()
                    ->modalHeading(fn(Account $record) => "Deduct from: {$record->number}"),

                ActionGroup::make([
                    EditAction::make(),
                    DeleteAction::make(),
                ])->label('More'),
            ])
            ->defaultSort('number');
    }
}
