<?php
namespace App\Filament\Resources\Billing\Accounts\Schemas;
use App\Models\Billing\Account;
use App\Models\Billing\Pricelist;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Section;
use Filament\Forms\Form;

class AccountForm
{
    public static function configure(Form $form): Form
    {
        return $form->schema([
            Section::make('Account Details')->columns(3)->schema([
                TextInput::make('number')->label('Account / SIP User')->required(),
                TextInput::make('first_name')->label('First Name'),
                TextInput::make('last_name')->label('Last Name'),
                TextInput::make('company_name')->label('Company'),
                TextInput::make('email')->email(),
                TextInput::make('telephone'),
            ]),
            Section::make('Billing Settings')->columns(3)->schema([
                Select::make('type')->label('Type')
                    ->options([-1 => 'Admin', 3 => 'Reseller', 0 => 'Customer'])
                    ->default(0)->required(),
                Select::make('pricelist_id')->label('Pricelist')
                    ->options(fn() => Pricelist::where('status', 0)->pluck('country', 'id'))
                    ->required(),
                Select::make('reseller_id')->label('Parent Reseller')
                    ->options(fn() => Account::where('type', 3)->pluck('company_name', 'id'))
                    ->nullable()->searchable(),
                TextInput::make('balance')->numeric()->default(0),
                TextInput::make('credit_limit')->label('Credit Limit')->numeric()->default(0),
                TextInput::make('maxchannels')->label('Max Channels')->numeric()->default(2),
                Select::make('status')->options([0 => 'Active', 1 => 'Inactive'])->default(0),
                TextInput::make('domain_uuid')->label('Domain UUID'),
                TextInput::make('extension'),
            ]),
        ]);
    }
}
