<?php
namespace App\Filament\Resources\Billing\Accounts\Pages;
use App\Filament\Resources\Billing\Accounts\AccountResource;
use Filament\Resources\Pages\ListRecords;
class ListAccounts extends ListRecords {
    protected static string $resource = AccountResource::class;
}
