<?php
namespace App\Filament\Resources\Billing\Accounts\Pages;
use App\Filament\Resources\Billing\Accounts\AccountResource;
use Filament\Resources\Pages\CreateRecord;
class CreateAccount extends CreateRecord {
    protected static string $resource = AccountResource::class;
}
