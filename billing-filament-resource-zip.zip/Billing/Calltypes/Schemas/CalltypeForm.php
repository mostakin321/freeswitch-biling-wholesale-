<?php
namespace App\Filament\Resources\Billing\Calltypes\Schemas;
use Carbon\Carbon;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Tabs;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
class CalltypeForm {
    public static function configure(Form $form): Form {
        return $form->schema([
            Tabs::make('Call Type')->columnSpanFull()->tabs([
                Tabs\Tab::make('Calltype Information')
                    ->icon('heroicon-o-tag')
                    ->schema([
                        Section::make('Call Type Details')
                            ->description('Define the call type name and status.')
                            ->icon('heroicon-o-identification')
                            ->columns(3)
                            ->schema([
                                TextInput::make('call_type')
                                    ->label('Name')->required()->placeholder('CLI')
                                    ->helperText('Name of the Call Type.'),
                                TextInput::make('description')
                                    ->label('Description')->placeholder('Caller ID shown')
                                    ->helperText('Self explanatory information about the Call Type.'),
                                Select::make('status')
                                    ->options([0=>'Active',1=>'Inactive'])->default(0)
                                    ->helperText('Status of Call Type.'),
                            ]),
                    ]),
            ]),
            Section::make('Record Info')
                ->icon('heroicon-o-information-circle')
                ->collapsed()->columns(2)
                ->schema([
                    Placeholder::make('id_info')->label('ID')->content(fn($record) => $record?->id ?? '—'),
                    Placeholder::make('date_info')->label('Date')
                        ->content(fn($record) => $record?->date ? Carbon::parse($record->date)->format('M j, Y') : '—'),
                ])->visibleOn('edit'),
        ]);
    }
}
