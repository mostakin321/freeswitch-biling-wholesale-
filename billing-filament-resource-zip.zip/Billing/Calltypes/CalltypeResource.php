<?php
namespace App\Filament\Resources\Billing\Calltypes;
use App\Models\Billing\Calltype;
use Filament\Resources\Resource;
use Filament\Forms\Form;
use Filament\Tables\Table;
class CalltypeResource extends Resource {
    protected static ?string $model           = Calltype::class;
    protected static ?string $navigationGroup = 'Billing';
    protected static ?string $navigationIcon  = 'heroicon-o-tag';
    protected static ?string $navigationLabel = 'Call Types';
    protected static ?int    $navigationSort  = 11;
    protected static ?string $modelLabel      = 'Call Type';
    protected static ?string $pluralModelLabel = 'Call Types';
    public static function form(Form $form): Form { return Schemas\CalltypeForm::configure($form); }
    public static function table(Table $table): Table { return Tables\CalltypesTable::configure($table); }
    public static function getRelations(): array { return []; }
    public static function getPages(): array {
        return [
            'index'  => Pages\ListCalltypes::route('/'),
            'create' => Pages\CreateCalltype::route('/create'),
            'edit'   => Pages\EditCalltype::route('/{record}/edit'),
        ];
    }
}
