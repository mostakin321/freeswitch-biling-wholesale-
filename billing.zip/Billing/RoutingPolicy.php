<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class RoutingPolicy extends Model {
    protected $connection = 'mysql';
    protected $table = 'routing_policies';
    protected $fillable = ['name','tenant','strategy','status'];
    public function routes() { return $this->hasMany(RoutingPolicyRoute::class); }
}
