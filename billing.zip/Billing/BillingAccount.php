<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BillingAccount extends Model
{
    protected $fillable = [
        'uuid', 'account_number', 'account_name', 'account_type',
        'parent_id', 'balance', 'credit_limit', 'currency', 'status',
    ];

    protected $casts = [
        'balance'      => 'decimal:6',
        'credit_limit' => 'decimal:6',
    ];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(BillingTransaction::class, 'account_id');
    }

    public function cdrs(): HasMany
    {
        return $this->hasMany(BillingCdr::class, 'account_id');
    }

    public function getAvailableBalanceAttribute(): float
    {
        return (float)$this->balance + (float)$this->credit_limit;
    }
}
