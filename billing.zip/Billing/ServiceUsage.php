<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class ServiceUsage extends Model {
    protected $table = 'service_usage';
    protected $guarded = [];
}
