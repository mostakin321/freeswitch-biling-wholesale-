<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class Reseller extends Model {
    protected $table = 'resellers';
    protected $guarded = [];
}
