<?php
namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Gateway extends BaseBillingModel
{
    protected $table = 'gateways';

    public const CREATED_AT = 'created_date';
    public const UPDATED_AT = 'last_modified_date';

    protected $fillable = [
        'sip_profile_id', 'name', 'gateway_data', 'accountid', 'status',
        'dialplan_variable', 'fs_gateway_uuid',
        'sip_proxy', 'sip_username', 'sip_password',
        'sip_from_user', 'sip_from_domain', 'sip_realm',
        'sip_register', 'sip_transport', 'sip_expire_seconds',
        'sip_retry_seconds', 'sip_cid_type',
        'sip_outbound_proxy', 'sip_caller_id_in_from',
        'sip_extension_in_contact', 'sip_extension', 'sip_contact_params',
    ];

    public function account(): BelongsTo
    {
        return $this->belongsTo(Account::class, 'accountid');
    }
}
