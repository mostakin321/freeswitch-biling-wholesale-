<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BillingCdr extends Model
{
    protected $table = 'billing_cdrs';

    protected $fillable = [
        'uuid', 'account_id', 'account_number', 'caller_number',
        'destination_number', 'call_direction', 'start_time',
        'answer_time', 'end_time', 'duration_sec', 'billsec',
        'rate_per_min', 'connect_cost', 'call_cost',
        'status', 'hangup_cause', 'gateway_id', 'trunk_id',
    ];

    protected $casts = [
        'start_time'   => 'datetime',
        'answer_time'  => 'datetime',
        'end_time'     => 'datetime',
        'rate_per_min' => 'decimal:6',
        'connect_cost' => 'decimal:6',
        'call_cost'    => 'decimal:6',
    ];

    public function account(): BelongsTo
    {
        return $this->belongsTo(BillingAccount::class, 'account_id');
    }
}
