<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class InvoiceItem extends Model {
    protected $connection = 'mysql';
    protected $table = 'invoice_items';
    protected $fillable = ['invoice_id','description','quantity','unit_price','amount'];
    public function invoice() { return $this->belongsTo(Invoice::class); }
}
