<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class Customer extends Model {
    protected $connection = 'mysql';
    protected $table = 'customers';
    protected $fillable = ['name','code','currency','status'];
    public function accounts() { return $this->hasMany(CustomerAccount::class); }
    public function invoices() { return $this->hasMany(Invoice::class); }
}
