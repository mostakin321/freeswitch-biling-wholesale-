<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class Supplier extends Model {
    protected $connection = 'mysql';
    protected $table = 'suppliers';
    protected $fillable = ['name','code','currency','status'];
    public function gateways() { return $this->hasMany(SupplierGateway::class); }
}
