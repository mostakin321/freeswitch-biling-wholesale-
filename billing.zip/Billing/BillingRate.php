<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BillingRate extends Model
{
    protected $table = 'billing_rates';

    protected $fillable = [
        'rate_group_id', 'prefix', 'destination',
        'rate_per_min', 'connect_cost', 'init_inc',
        'inc', 'min_duration', 'status', 'effective_date',
    ];

    protected $casts = [
        'rate_per_min'  => 'decimal:6',
        'connect_cost'  => 'decimal:6',
        'effective_date'=> 'date',
        'status'        => 'boolean',
    ];

    public function rateGroup(): BelongsTo
    {
        return $this->belongsTo(BillingRateGroup::class, 'rate_group_id');
    }
}
