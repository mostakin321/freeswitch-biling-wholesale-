<?php
namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OutboundRoute extends Model
{
    protected $table = 'outbound_routes';

    protected $fillable = [
        'pricelist_id', 'trunk_id', 'prefix', 'pattern',
        'comment', 'destination', 'cost', 'buy_cost',
        'connectcost', 'init_inc', 'inc', 'tech_prefix',
        'priority', 'status',
    ];

    protected $casts = [
        'cost'       => 'decimal:5',
        'buy_cost'   => 'decimal:5',
        'connectcost'=> 'decimal:5',
    ];

    public function pricelist(): BelongsTo
    {
        return $this->belongsTo(Pricelist::class);
    }

    public function trunk(): BelongsTo
    {
        return $this->belongsTo(Trunk::class);
    }

    // Auto-generate regex pattern from prefix
    public static function prefixToPattern(string $prefix): string
    {
        return '^' . preg_quote($prefix, '/') . '.*';
    }
}
