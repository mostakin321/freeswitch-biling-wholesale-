<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

abstract class BaseBillingModel extends Model
{
    use HasFactory;

    protected $connection = 'mysql';
    public $incrementing  = true;
    protected $keyType    = 'int';
    protected $guarded    = [];
    public $timestamps    = true;

    public const CREATED_AT = 'creation_date';
    public const UPDATED_AT = 'last_modified_date';

    protected $casts = [
        'creation_date'      => 'datetime',
        'last_modified_date' => 'datetime',
    ];
}
