<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class RoutingPolicyRoute extends Model {
    protected $connection = 'mysql';
    protected $table = 'routing_policy_routes';
    protected $fillable = ['routing_policy_id','supplier_gateway_id','priority','weight','status'];
    public function policy() { return $this->belongsTo(RoutingPolicy::class, 'routing_policy_id'); }
    public function supplierGateway() { return $this->belongsTo(SupplierGateway::class); }
}
