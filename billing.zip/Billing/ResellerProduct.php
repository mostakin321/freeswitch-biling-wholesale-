<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class ResellerProduct extends Model {
    protected $table = 'reseller_products';
    protected $guarded = [];
}
