<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class UsageSummary extends Model {
    protected $connection = 'mysql';
    protected $table = 'service_usage';
    protected $fillable = ['customer_account_id','period_start','period_end','call_count','billable_seconds','sell_amount','buy_amount','margin_amount'];
    public function customerAccount() { return $this->belongsTo(CustomerAccount::class); }
}
