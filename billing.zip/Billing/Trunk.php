<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\FusionPBX\Gateway;

class Trunk extends Model
{
    protected $table = 'trunks';

    protected $fillable = [
        'name',
        'provider_id',          // accounts.id where type=3 (carrier/provider)
        'gateway_id',           // v_gateways.gateway_uuid (primary FreeSWITCH gateway)
        'failover_gateway_id',  // v_gateways.gateway_uuid (failover #1)
        'failover_gateway_id1', // v_gateways.gateway_uuid (failover #2)
        'gateway_name',         // human-readable name of primary gateway
        'localization_id',
        'sip_cid_type',
        'precedence',
        'codec',
        'leg_timeout',
        'maxchannels',
        'cps',
        'strip_digit',
        'add_prefix',
        'add_suffix',
        'tech_prefix',
        'sip_profile',
        'register',
        'status',
        'notes',
    ];

    protected $casts = [
        'register' => 'boolean',
    ];

    // SIP CID type options (how CallerID shows in outbound SIP header)
    const SIP_CID_TYPES = [
        'none'  => 'None (pass-through)',
        'pid'   => 'P-Asserted-Identity',
        'rpid'  => 'Remote-Party-ID',
        'from'  => 'From Header',
    ];

    // ── Relationships ─────────────────────────────────────────────

    /**
     * Provider/carrier account (accounts.type = 3 in ASTPP)
     * This is the company you buy from (carrier)
     */
    public function provider(): BelongsTo
    {
        return $this->belongsTo(Account::class, 'provider_id');
    }

    /**
     * Outbound routes using this trunk
     */
    public function outboundRoutes(): HasMany
    {
        return $this->hasMany(OutboundRoute::class, 'trunk_id');
    }

    // ── FusionPBX gateway lookups (cross-DB) ─────────────────────

    /**
     * Primary FreeSWITCH gateway (v_gateways)
     */
    public function primaryGateway(): ?Gateway
    {
        if (empty($this->gateway_id)) return null;
        return Gateway::where('gateway_uuid', $this->gateway_id)->first();
    }

    /**
     * Failover gateway #1
     */
    public function failoverGateway1(): ?Gateway
    {
        if (empty($this->failover_gateway_id)) return null;
        return Gateway::where('gateway_uuid', $this->failover_gateway_id)->first();
    }

    /**
     * Failover gateway #2
     */
    public function failoverGateway2(): ?Gateway
    {
        if (empty($this->failover_gateway_id1)) return null;
        return Gateway::where('gateway_uuid', $this->failover_gateway_id1)->first();
    }

    /**
     * Get the dial string for FreeSWITCH bridge command
     * Applies strip_digit and add_prefix to destination number
     */
    public function buildDialString(string $destination): string
    {
        $number = $destination;

        // Strip N digits from start
        if ($this->strip_digit > 0) {
            $number = substr($number, $this->strip_digit);
        }

        // Add prefix
        if (!empty($this->add_prefix)) {
            $number = $this->add_prefix . $number;
        }

        // Add suffix
        if (!empty($this->add_suffix)) {
            $number = $number . $this->add_suffix;
        }

        // Tech prefix for carrier auth
        $techPrefix = !empty($this->tech_prefix) ? $this->tech_prefix : '';

        // Build bridge string using gateway UUID (FreeSWITCH internal format)
        return "sofia/gateway/{$techPrefix}{$this->gateway_id}/{$number}";
    }

    /**
     * Build full failover dial string with all 3 gateways
     * FreeSWITCH tries them in order: primary | failover1 | failover2
     */
    public function buildFailoverDialString(string $destination): string
    {
        $parts = [];
        $number = $this->applyNumberTranslation($destination);

        if (!empty($this->gateway_id)) {
            $parts[] = "sofia/gateway/{$this->gateway_id}/{$number}";
        }
        if (!empty($this->failover_gateway_id)) {
            $parts[] = "sofia/gateway/{$this->failover_gateway_id}/{$number}";
        }
        if (!empty($this->failover_gateway_id1)) {
            $parts[] = "sofia/gateway/{$this->failover_gateway_id1}/{$number}";
        }

        return implode('|', $parts); // | = sequential failover in FreeSWITCH
    }

    /**
     * Apply digit manipulation: strip + add_prefix + add_suffix
     */
    public function applyNumberTranslation(string $destination): string
    {
        $number = $destination;
        if ($this->strip_digit > 0) {
            $number = substr($number, (int)$this->strip_digit);
        }
        if (!empty($this->add_prefix)) {
            $number = $this->add_prefix . $number;
        }
        if (!empty($this->add_suffix)) {
            $number = $number . $this->add_suffix;
        }
        return $number;
    }
}
