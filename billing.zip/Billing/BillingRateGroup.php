<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BillingRateGroup extends Model
{
    protected $table = 'billing_rate_groups';
    protected $fillable = ['name', 'description', 'currency', 'status'];

    public function rates(): HasMany
    {
        return $this->hasMany(BillingRate::class, 'rate_group_id');
    }
}
