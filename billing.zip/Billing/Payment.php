<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class Payment extends Model {
    protected $connection = 'mysql';
    protected $table = 'payments';
    protected $fillable = ['customer_id','invoice_id','amount','currency','method','reference','status','paid_at'];
    public function customer() { return $this->belongsTo(Customer::class); }
    public function invoice() { return $this->belongsTo(Invoice::class); }
}
