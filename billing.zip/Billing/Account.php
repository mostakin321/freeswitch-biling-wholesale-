<?php
namespace App\Models\Billing;

use App\Models\AccountTransactionLog;
use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    protected $connection = 'mysql';
    protected $table      = 'accounts';
    public    $timestamps = false;

    protected $fillable = [
        'number','reseller_id','pricelist_id','status','balance',
        'credit_limit','posttoexternal','first_name','last_name',
        'company_name','email','telephone','maxchannels','cps',
        'type','currency_id','is_recording','deleted','expiry',
        'sell_pricelist_id','buy_pricelist_id','domain_uuid',
        'user_uuid','extension','fx_group','notify_credit_limit',
        'notify_flag','notify_email','sms_pricelist_id',
        'loss_less_routing','min_call_duration','allow_billing',
    ];

    public function transactions()
    {
        return $this->hasMany(AccountTransactionLog::class, 'accountid');
    }
}
