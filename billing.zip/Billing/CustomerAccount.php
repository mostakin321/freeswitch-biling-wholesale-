<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class CustomerAccount extends Model {
    protected $connection = 'mysql';
    protected $table = 'customer_accounts';
    protected $fillable = ['customer_id','account_code','tech_prefix','cgr_tenant','cgr_account','balance','credit_limit','max_channels','status'];
    public function customer() { return $this->belongsTo(Customer::class); }
    public function usageSummaries() { return $this->hasMany(UsageSummary::class); }
}
