<?php
namespace App\Models\Billing;
use Illuminate\Database\Eloquent\Model;
class SupplierGateway extends Model {
    protected $connection = 'mysql';
    protected $table = 'supplier_gateways';
    protected $fillable = ['supplier_id','name','gateway_ref','tech_prefix','strip_digits','fs_gateway_uuid','status'];
    public function supplier() { return $this->belongsTo(Supplier::class); }
}
