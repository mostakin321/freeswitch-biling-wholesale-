<?php
use App\Http\Controllers\Api\Dialer\AgentController;
use App\Http\Controllers\Api\Dialer\CallResultController;
use App\Http\Controllers\Api\Dialer\CampaignController;
use App\Http\Controllers\Api\Dialer\ContactController;
use App\Http\Controllers\Api\Dialer\DncController;
use App\Http\Controllers\Api\Dialer\MetricsController;
use App\Http\Controllers\Api\Dialer\WebhookController;
use Illuminate\Support\Facades\Route;

// ── Webhooks (no auth — FreeSWITCH internal) ──────────────────
Route::prefix('v1/dialer/webhook')->group(function () {
    Route::post('/cdr',          [WebhookController::class, 'cdr']);
    Route::post('/agent-state',  [WebhookController::class, 'agentState']);
    Route::post('/call-event',   [WebhookController::class, 'callEvent']);
});

// ── Authenticated API ─────────────────────────────────────────
Route::middleware('auth:sanctum')->prefix('v1/dialer')->group(function () {

    // Campaigns (13 endpoints)
    Route::get   ('/campaigns',           [CampaignController::class, 'index']);
    Route::post  ('/campaigns',           [CampaignController::class, 'store']);
    Route::get   ('/campaigns/{campaign}',[CampaignController::class, 'show']);
    Route::put   ('/campaigns/{campaign}',[CampaignController::class, 'update']);
    Route::delete('/campaigns/{campaign}',[CampaignController::class, 'destroy']);
    Route::post  ('/campaigns/{campaign}/start',  [CampaignController::class, 'start']);
    Route::post  ('/campaigns/{campaign}/stop',   [CampaignController::class, 'stop']);
    Route::post  ('/campaigns/{campaign}/pause',  [CampaignController::class, 'pause']);
    Route::post  ('/campaigns/{campaign}/resume', [CampaignController::class, 'resume']);
    Route::post  ('/campaigns/{campaign}/reset',  [CampaignController::class, 'reset']);
    Route::post  ('/campaigns/{campaign}/clone',  [CampaignController::class, 'clone']);
    Route::patch ('/campaigns/{campaign}/pacing', [CampaignController::class, 'updatePacing']);
    Route::get   ('/campaigns/{campaign}/metrics',[MetricsController::class,  'campaign']);

    // Contacts (9 endpoints)
    Route::get   ('/campaigns/{campaign}/contacts',        [ContactController::class, 'index']);
    Route::post  ('/campaigns/{campaign}/contacts',        [ContactController::class, 'store']);
    Route::post  ('/campaigns/{campaign}/contacts/import', [ContactController::class, 'import']);
    Route::delete('/campaigns/{campaign}/contacts',        [ContactController::class, 'destroyAll']);
    Route::get   ('/contacts/{contact}',                   [ContactController::class, 'show']);
    Route::put   ('/contacts/{contact}',                   [ContactController::class, 'update']);
    Route::delete('/contacts/{contact}',                   [ContactController::class, 'destroy']);
    Route::post  ('/contacts/{contact}/reschedule',        [ContactController::class, 'reschedule']);
    Route::post  ('/contacts/{contact}/block',             [ContactController::class, 'block']);

    // Results / CDR (4 endpoints)
    Route::get('/campaigns/{campaign}/results',        [CallResultController::class, 'index']);
    Route::get('/campaigns/{campaign}/results/export', [CallResultController::class, 'export']);
    Route::get('/results',                             [CallResultController::class, 'all']);
    Route::get('/results/{result}',                    [CallResultController::class, 'show']);

    // DNC (6 endpoints)
    Route::get   ('/dnc',                [DncController::class, 'index']);
    Route::post  ('/dnc',                [DncController::class, 'store']);
    Route::post  ('/dnc/import',         [DncController::class, 'import']);
    Route::get   ('/dnc/check/{phone}',  [DncController::class, 'check']);
    Route::delete('/dnc/{phone}',        [DncController::class, 'destroy']);
    Route::delete('/dnc',                [DncController::class, 'destroyAll']);

    // Agents — FusionPBX PostgreSQL read-only (3 endpoints)
    Route::get('/agents',           [AgentController::class, 'index']);
    Route::get('/agents/available', [AgentController::class, 'available']);
    Route::get('/agents/{agent}',   [AgentController::class, 'show']);

    // Metrics (5 endpoints)
    Route::get('/metrics',          [MetricsController::class, 'global']);
    Route::get('/metrics/realtime', [MetricsController::class, 'realtime']);
    Route::get('/metrics/hourly',   [MetricsController::class, 'hourly']);
    Route::get('/metrics/daily',    [MetricsController::class, 'daily']);
    Route::get('/metrics/pacing',   [MetricsController::class, 'pacing']);
});
