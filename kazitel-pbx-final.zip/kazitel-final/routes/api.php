<?php
use App\Http\Controllers\Api\Dialer\CampaignController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// ── Auth — get Sanctum token ───────────────────────────────────
Route::post('/v1/login', function (Request $request) {
    $request->validate(['email'=>'required|email','password'=>'required']);
    $user = \App\Models\User::where('email', $request->email)->first();
    if (!$user || !\Illuminate\Support\Facades\Hash::check($request->password, $user->password)) {
        return response()->json(['error' => 'Invalid credentials.'], 401);
    }
    $token = $user->createToken('dialer-api')->plainTextToken;
    return response()->json(['token' => $token, 'email' => $user->email]);
});

// ── Dialer REST API (v1) ───────────────────────────────────────
require base_path('routes/dialer.php');
