<?php

namespace App\Models\Dialer;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class DialerContact extends Model
{
    use HasUuids;

    protected $connection   = 'mysql';
    protected $table        = 'dialer_contacts';
    protected $keyType      = 'string';
    public    $incrementing = false;

    protected $fillable = [
        'campaign_id','phone','name','email','timezone','priority',
        'status','disposition','attempt_count','last_called_at','retry_after','custom_data',
    ];

    protected $casts = [
        'custom_data'    => 'array',
        'last_called_at' => 'datetime',
        'retry_after'    => 'datetime',
    ];

    public function campaign() { return $this->belongsTo(DialerCampaign::class,'campaign_id'); }
    public function results()  { return $this->hasMany(DialerCallResult::class,'contact_id'); }

    public function scopePending($q)      { return $q->where('status','pending'); }
    public function scopeReadyToCall($q)  { return $q->where('status','pending')->where(fn($s)=>$s->whereNull('retry_after')->orWhere('retry_after','<=',now())); }
    public function scopeOrderByPriority($q) { return $q->orderBy('priority','asc')->orderBy('created_at','asc'); }
}
