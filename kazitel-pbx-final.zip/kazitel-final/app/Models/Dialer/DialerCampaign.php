<?php

namespace App\Models\Dialer;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DialerCampaign extends Model
{
    use HasUuids;

    protected $connection   = 'mysql';
    protected $table        = 'dialer_campaigns';
    protected $keyType      = 'string';
    public    $incrementing = false;

    protected $fillable = [
        'name','description','status','pacing_mode','queue_name','gateway_name',
        'caller_id_number','caller_id_name','calling_hours_start','calling_hours_end',
        'timezone','call_on_saturday','call_on_sunday','target_aht_seconds',
        'initial_answer_rate','max_attempts','leave_voicemail','voicemail_file',
        'abandoned_message_file','domain_uuid','started_at','completed_at',
    ];

    protected $casts = [
        'call_on_saturday'   => 'boolean',
        'call_on_sunday'     => 'boolean',
        'leave_voicemail'    => 'boolean',
        'initial_answer_rate'=> 'float',
        'started_at'         => 'datetime',
        'completed_at'       => 'datetime',
    ];

    public function contacts(): HasMany { return $this->hasMany(DialerContact::class,'campaign_id'); }
    public function results():  HasMany { return $this->hasMany(DialerCallResult::class,'campaign_id'); }

    public function canStart(): bool
    {
        return in_array($this->status,['pending','paused'])
            && $this->contacts()->where('status','pending')->exists();
    }

    public function progressPercent(): float
    {
        $total = $this->contacts()->count();
        if ($total === 0) return 0.0;
        $done  = $this->contacts()->whereNotIn('status',['pending','dialing'])->count();
        return round($done / $total * 100, 1);
    }

    public function abandonRateLive(): float
    {
        $results = $this->results()->whereDate('called_at', today());
        $answered = $results->where('disposition','ANSWERED')->count();
        if ($answered === 0) return 0.0;
        $abandoned = $results->where('agent_answered', false)->where('disposition','ANSWERED')->count();
        return round($abandoned / $answered * 100, 2);
    }

    public function scopeRunning($q)   { return $q->where('status','running'); }
    public function scopePending($q)   { return $q->where('status','pending'); }
    public function scopeCompleted($q) { return $q->where('status','completed'); }
}
