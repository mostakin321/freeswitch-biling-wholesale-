<?php

namespace App\Models\Dialer;

use Illuminate\Database\Eloquent\Model;

class DialerDnc extends Model
{
    protected $connection = 'mysql';
    protected $table      = 'dialer_dnc';
    protected $fillable   = ['phone','reason','domain_uuid','added_at'];
    protected $casts      = ['added_at' => 'datetime'];
}
