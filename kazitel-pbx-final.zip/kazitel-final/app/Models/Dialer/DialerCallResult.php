<?php

namespace App\Models\Dialer;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class DialerCallResult extends Model
{
    use HasUuids;

    protected $connection   = 'mysql';
    protected $table        = 'dialer_call_results';
    protected $keyType      = 'string';
    public    $incrementing = false;

    protected $fillable = [
        'campaign_id','contact_id','uuid','disposition',
        'duration','agent_answered','agent_extension','called_at','raw_cdr',
    ];

    protected $casts = [
        'agent_answered' => 'boolean',
        'called_at'      => 'datetime',
        'raw_cdr'        => 'array',
    ];

    public function campaign() { return $this->belongsTo(DialerCampaign::class,'campaign_id'); }
    public function contact()  { return $this->belongsTo(DialerContact::class,'contact_id'); }
}
