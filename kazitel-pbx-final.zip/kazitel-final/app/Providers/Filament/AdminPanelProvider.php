<?php
namespace App\Providers\Filament;
use App\Filament\Resources\Dialer\DialerCampaignResource;
use App\Filament\Resources\Dialer\DialerDncResource;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Navigation\NavigationGroup;
use Filament\Pages;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Widgets;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\AuthenticateSession;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        $wl      = config('whitelabel', []);
        $appName = $wl['app_name']      ?? 'Kazitel PBX';
        $hex     = $wl['primary_hex']   ?? null;
        $primary = $wl['primary_color'] ?? 'amber';
        $path    = $wl['admin_path']    ?? 'admin';
        $dark    = (bool)($wl['dark_mode'] ?? false);

        $colorMap = [
            'amber'=>Color::Amber,'blue'=>Color::Blue,'cyan'=>Color::Cyan,
            'emerald'=>Color::Emerald,'green'=>Color::Green,'indigo'=>Color::Indigo,
            'orange'=>Color::Orange,'pink'=>Color::Pink,'purple'=>Color::Purple,
            'red'=>Color::Red,'rose'=>Color::Rose,'sky'=>Color::Sky,
            'teal'=>Color::Teal,'violet'=>Color::Violet,'yellow'=>Color::Yellow,
        ];
        $primaryColor = $hex ? Color::hex($hex) : ($colorMap[$primary] ?? Color::Amber);

        return $panel
            ->default()
            ->id('admin')
            ->path($path)
            ->login()
            ->brandName($appName)
            ->darkMode($dark)
            ->colors(['primary'=>$primaryColor,'danger'=>Color::Red,'gray'=>Color::Slate,'info'=>Color::Sky,'success'=>Color::Emerald,'warning'=>Color::Amber])
            ->resources([
                // ── Predictive Dialer ──────────────────────────
                DialerCampaignResource::class,
                DialerDncResource::class,
                // ── Add more resources here ────────────────────
            ])
            ->pages([Pages\Dashboard::class])
            ->widgets([Widgets\AccountWidget::class])
            ->navigationGroups([
                NavigationGroup::make('Predictive Dialer')->icon('heroicon-o-phone-arrow-up-right')->collapsible(),
                NavigationGroup::make('System')->icon('heroicon-o-cog-6-tooth')->collapsible(),
                NavigationGroup::make('White Label')->icon('heroicon-o-paint-brush')->collapsible(),
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([Authenticate::class]);
    }
}
