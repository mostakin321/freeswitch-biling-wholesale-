<?php
namespace App\Providers;
use App\Services\PredictiveDialerEngine;
use App\Services\DialingRatioCalculator;
use App\Services\AI\AiCopilotService;
use Illuminate\Support\ServiceProvider;
class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(PredictiveDialerEngine::class);
        $this->app->singleton(DialingRatioCalculator::class);
        $this->app->singleton(AiCopilotService::class);
    }
    public function boot(): void
    {
        view()->share('whitelabel', config('whitelabel', []));
    }
}
