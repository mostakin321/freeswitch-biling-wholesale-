<?php
namespace App\Jobs;
use App\Models\Dialer\DialerCampaign;
use App\Services\PredictiveDialerEngine;
use App\Services\DialingRatioCalculator;
use App\Services\AgentAvailabilityMonitor;
use App\Services\FreeSwitchDialerService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
class ProcessDialerCampaignJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable;
    public int $timeout = 86400;
    public int $tries   = 1;
    public function __construct(public DialerCampaign $campaign) {}
    public function handle(PredictiveDialerEngine $engine, DialingRatioCalculator $calc, AgentAvailabilityMonitor $monitor, FreeSwitchDialerService $fs): void
    {
        Log::info("[Dialer] Campaign '{$this->campaign->name}' starting.");
        if (!$fs->connect()) { Log::error("[Dialer] Cannot connect to FreeSWITCH ESL."); $this->campaign->update(['status'=>'paused']); return; }
        while (true) {
            $this->campaign->refresh();
            if (!in_array($this->campaign->status, ['running'])) { Log::info("[Dialer] Campaign stopped."); break; }
            if (Cache::has("dialer:campaign:{$this->campaign->id}:throttle")) { sleep(5); continue; }
            $idle    = $monitor->getIdleCount($this->campaign->queue_name);
            $metrics = $engine->gatherMetrics($this->campaign);
            $metrics['idle_agents'] = $idle;
            $monitor->updateCache($this->campaign->id, $metrics);
            $dialCount = $calc->calculate($metrics, $this->campaign->pacing_mode);
            if ($dialCount > 0) {
                $contacts = $this->campaign->contacts()->readyToCall()->orderByPriority()->limit($dialCount)->get();
                if ($contacts->isEmpty()) { $this->campaign->update(['status'=>'completed','completed_at'=>now()]); break; }
                foreach ($contacts as $contact) {
                    $contact->update(['status'=>'dialing','last_called_at'=>now(),'attempt_count'=>$contact->attempt_count+1]);
                    OriginateCallJob::dispatch($contact, $this->campaign)->onQueue('dialer');
                }
            }
            sleep(3);
        }
        $fs->disconnect();
    }
}
