<?php
namespace App\Jobs;
use App\Models\Dialer\DialerContact;
use App\Models\Dialer\DialerCampaign;
use App\Services\FreeSwitchDialerService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;
class OriginateCallJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable;
    public int $tries   = 1;
    public int $timeout = 60;
    public function __construct(public DialerContact $contact, public DialerCampaign $campaign) {}
    public function handle(FreeSwitchDialerService $fs): void
    {
        if (!$fs->connect()) { $this->contact->update(['status'=>'pending']); return; }
        try {
            $uuid = $fs->originate($this->contact->phone, $this->campaign->gateway_name, $this->campaign->queue_name, $this->campaign->caller_id_number, ['dialer_campaign_id'=>$this->campaign->id,'dialer_contact_id'=>$this->contact->id,'effective_caller_id_name'=>$this->campaign->caller_id_name??$this->campaign->caller_id_number]);
            Log::info("[OriginateCall] UUID: {$uuid} Phone: {$this->contact->phone}");
        } catch (\Throwable $e) {
            Log::error("[OriginateCall] Failed for {$this->contact->phone}: " . $e->getMessage());
            $this->contact->update(['status'=>'failed','disposition'=>'FAILED']);
        } finally {
            $fs->disconnect();
        }
    }
}
