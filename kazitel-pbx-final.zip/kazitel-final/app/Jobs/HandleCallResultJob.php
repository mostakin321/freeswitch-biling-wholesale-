<?php
namespace App\Jobs;
use App\Models\Dialer\DialerContact;
use App\Models\Dialer\DialerCallResult;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Str;
class HandleCallResultJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable;
    public function __construct(public string $uuid, public string $disposition, public int $duration, public bool $agentAnswered, public array $rawCdr) {}
    public function handle(): void
    {
        // Find contact by UUID in custom_data or via call UUID
        $contact = DialerContact::where('status','dialing')->latest('last_called_at')->first();
        if (!$contact) return;
        DialerCallResult::create(['id'=>Str::uuid()->toString(),'campaign_id'=>$contact->campaign_id,'contact_id'=>$contact->id,'uuid'=>$this->uuid,'disposition'=>$this->disposition,'duration'=>$this->duration,'agent_answered'=>$this->agentAnswered,'called_at'=>now(),'raw_cdr'=>$this->rawCdr]);
        $statusMap = ['ANSWERED'=>'answered','BUSY'=>'busy','NO ANSWER'=>'no_answer','VOICEMAIL'=>'voicemail','FAILED'=>'failed','INVALID_NUMBER'=>'failed'];
        $newStatus = $statusMap[$this->disposition] ?? 'failed';
        $contact->update(['status'=>$newStatus,'disposition'=>strtolower($this->disposition),'last_called_at'=>now()]);
    }
}
