<?php
namespace App\Console\Commands;
use App\Jobs\ProcessDialerCampaignJob;
use App\Models\Dialer\DialerCampaign;
use App\Models\Dialer\DialerDnc;
use App\Services\PredictiveDialerEngine;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
class DialerCommand extends Command
{
    protected $signature = 'dialer {action : start|stop|status|import|dnc:import} {campaign? : Campaign UUID} {file? : CSV path for import}';
    protected $description = 'Manage predictive dialer campaigns';
    public function handle(): int
    {
        return match($this->argument('action')) {
            'start'      => $this->startCampaign(),
            'stop'       => $this->stopCampaign(),
            'status'     => $this->showStatus(),
            'import'     => $this->importContacts(),
            'dnc:import' => $this->importDnc(),
            default      => $this->error("Unknown action. Use: start|stop|status|import|dnc:import") ?? 1,
        };
    }
    private function startCampaign(): int
    {
        $campaign = $this->getCampaign();
        if (!$campaign) return 1;
        if (!$campaign->canStart()) { $this->error("Cannot start campaign '{$campaign->name}'. Status: {$campaign->status}"); return 1; }
        ProcessDialerCampaignJob::dispatch($campaign)->onQueue('dialer');
        $campaign->update(['status'=>'running','started_at'=>now()]);
        $this->info("✓ Campaign '{$campaign->name}' started.");
        return 0;
    }
    private function stopCampaign(): int
    {
        $campaign = $this->getCampaign();
        if (!$campaign) return 1;
        app(PredictiveDialerEngine::class)->stopCampaign($campaign);
        $this->info("✓ Campaign '{$campaign->name}' stopped.");
        return 0;
    }
    private function showStatus(): int
    {
        $campaigns = DialerCampaign::withCount(['contacts','results'])->get();
        $this->table(['ID','Name','Status','Pacing','Contacts','Dialed','Progress'],
            $campaigns->map(fn($c)=>[$c->id,$c->name,$c->status,$c->pacing_mode,$c->contacts_count,$c->results_count,$c->progressPercent().'%'])->toArray());
        return 0;
    }
    private function importContacts(): int
    {
        $campaign = $this->getCampaign();
        $file     = $this->argument('file');
        if (!$campaign || !$file) { $this->error('Usage: php artisan dialer import {campaign-uuid} {/path/to/file.csv}'); return 1; }
        if (!file_exists($file)) { $this->error("File not found: {$file}"); return 1; }
        $handle  = fopen($file,'r');
        $headers = array_map('strtolower', fgetcsv($handle));
        $count = 0;
        while ($row = fgetcsv($handle)) {
            $data = array_combine($headers, array_slice($row,0,count($headers)));
            DB::table('dialer_contacts')->insertOrIgnore(['id'=>\Illuminate\Support\Str::uuid()->toString(),'campaign_id'=>$campaign->id,'phone'=>$data['phone']??'','name'=>$data['name']??null,'email'=>$data['email']??null,'priority'=>(int)($data['priority']??5),'status'=>'pending','attempt_count'=>0,'created_at'=>now(),'updated_at'=>now()]);
            $count++;
        }
        fclose($handle);
        $this->info("✓ {$count} contacts imported into '{$campaign->name}'.");
        return 0;
    }
    private function importDnc(): int
    {
        $file = $this->argument('campaign');
        if (!$file || !file_exists($file)) { $this->error('Usage: php artisan dialer dnc:import /path/to/dnc.csv'); return 1; }
        $handle  = fopen($file,'r');
        $headers = array_map('strtolower', fgetcsv($handle));
        $count = 0;
        while ($row = fgetcsv($handle)) {
            $data  = array_combine($headers, array_slice($row,0,count($headers)));
            $phone = preg_replace('/[^0-9+]/','',trim($data['phone']??''));
            if (!$phone) continue;
            DialerDnc::firstOrCreate(['phone'=>$phone],['reason'=>$data['reason']??'CSV import','added_at'=>now()]);
            $count++;
        }
        fclose($handle);
        $this->info("✓ {$count} numbers imported to DNC.");
        return 0;
    }
    private function getCampaign(): ?DialerCampaign
    {
        $uuid = $this->argument('campaign');
        if (!$uuid) { $this->error('Campaign UUID is required.'); return null; }
        $campaign = DialerCampaign::find($uuid);
        if (!$campaign) { $this->error("Campaign not found: {$uuid}"); return null; }
        return $campaign;
    }
}
