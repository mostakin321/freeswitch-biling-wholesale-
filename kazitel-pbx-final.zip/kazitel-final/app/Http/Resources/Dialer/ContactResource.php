<?php
namespace App\Http\Resources\Dialer;
use Illuminate\Http\Resources\Json\JsonResource;
class ContactResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id'             => $this->id,
            'campaign_id'    => $this->campaign_id,
            'phone'          => $this->phone,
            'name'           => $this->name,
            'email'          => $this->email,
            'timezone'       => $this->timezone,
            'priority'       => $this->priority,
            'status'         => $this->status,
            'disposition'    => $this->disposition,
            'attempt_count'  => $this->attempt_count,
            'last_called_at' => $this->last_called_at?->toIso8601String(),
            'retry_after'    => $this->retry_after?->toIso8601String(),
            'custom_data'    => $this->custom_data,
            'created_at'     => $this->created_at->toIso8601String(),
        ];
    }
}
