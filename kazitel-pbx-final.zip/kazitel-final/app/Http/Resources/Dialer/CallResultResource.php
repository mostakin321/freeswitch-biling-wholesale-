<?php
namespace App\Http\Resources\Dialer;
use Illuminate\Http\Resources\Json\JsonResource;
class CallResultResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id'              => $this->id,
            'uuid'            => $this->uuid,
            'campaign_id'     => $this->campaign_id,
            'campaign_name'   => $this->whenLoaded('campaign', fn() => $this->campaign->name),
            'contact'         => $this->whenLoaded('contact', fn() => ['id'=>$this->contact->id,'phone'=>$this->contact->phone,'name'=>$this->contact->name]),
            'disposition'     => $this->disposition,
            'duration'        => $this->duration,
            'agent_answered'  => $this->agent_answered,
            'agent_extension' => $this->agent_extension,
            'called_at'       => $this->called_at?->toIso8601String(),
        ];
    }
}
