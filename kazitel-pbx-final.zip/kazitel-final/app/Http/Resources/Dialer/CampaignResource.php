<?php
namespace App\Http\Resources\Dialer;
use Illuminate\Http\Resources\Json\JsonResource;
class CampaignResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id'           => $this->id,
            'name'         => $this->name,
            'description'  => $this->description,
            'status'       => $this->status,
            'pacing_mode'  => $this->pacing_mode,
            'queue_name'   => $this->queue_name,
            'gateway_name' => $this->gateway_name,
            'caller_id'    => ['number'=>$this->caller_id_number,'name'=>$this->caller_id_name],
            'calling_hours'=> ['start'=>$this->calling_hours_start,'end'=>$this->calling_hours_end,'timezone'=>$this->timezone,'saturday'=>$this->call_on_saturday,'sunday'=>$this->call_on_sunday],
            'algorithm'    => ['aht_seconds'=>$this->target_aht_seconds,'answer_rate'=>$this->initial_answer_rate,'max_attempts'=>$this->max_attempts],
            'voicemail'    => ['enabled'=>$this->leave_voicemail,'file'=>$this->voicemail_file],
            'stats'        => ['contacts'=>$this->whenCounted('contacts'),'results'=>$this->whenCounted('results')],
            'started_at'   => $this->started_at?->toIso8601String(),
            'completed_at' => $this->completed_at?->toIso8601String(),
            'created_at'   => $this->created_at->toIso8601String(),
            'updated_at'   => $this->updated_at->toIso8601String(),
        ];
    }
}
