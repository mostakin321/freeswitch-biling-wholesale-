<?php

namespace App\Http\Controllers\Api\Dialer;

use App\Http\Controllers\Controller;
use App\Http\Resources\Dialer\CallResultResource;
use App\Models\Dialer\DialerCampaign;
use App\Models\Dialer\DialerCallResult;
use App\Models\Dialer\DialerContact;
use App\Models\Dialer\DialerDnc;
use App\Services\PredictiveDialerEngine;
use App\Services\DialingRatioCalculator;
use App\Jobs\HandleCallResultJob;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

// ════════════════════════════════════════════════════════════
// METRICS CONTROLLER
// ════════════════════════════════════════════════════════════
class MetricsController extends Controller
{
    public function __construct(protected PredictiveDialerEngine $engine, protected DialingRatioCalculator $calc) {}

    /**
     * @OA\Get(path="/dialer/campaigns/{id}/metrics", tags={"Metrics"}, summary="Live campaign metrics (ESL + PostgreSQL agents)",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Live metrics", @OA\JsonContent(@OA\Property(property="data", ref="#/components/schemas/CampaignMetrics")))
     * )
     */
    public function campaign(DialerCampaign $campaign): JsonResponse
    {
        $live    = $this->engine->gatherMetrics($campaign);
        $results = $campaign->results();
        return response()->json(['data' => [
            'campaign_id'      => $campaign->id,
            'campaign_name'    => $campaign->name,
            'status'           => $campaign->status,
            'pacing_mode'      => $campaign->pacing_mode,
            'progress_percent' => $campaign->progressPercent(),
            'contacts_total'   => $campaign->contacts()->count(),
            'contacts_pending' => $campaign->contacts()->where('status','pending')->count(),
            'contacts_done'    => $campaign->contacts()->whereNotIn('status',['pending','dialing'])->count(),
            'active_calls'     => $live['active_calls'] ?? 0,
            'idle_agents'      => $live['idle_agents']  ?? 0,
            'busy_agents'      => $live['busy_agents']  ?? 0,
            'total_agents'     => $live['total_agents'] ?? 0,
            'occupancy'        => round(($live['occupancy'] ?? 0) * 100, 1),
            'answer_rate'      => round(($live['answer_rate'] ?? 0) * 100, 1),
            'abandon_rate'     => $campaign->abandonRateLive(),
            'avg_handle_time'  => $live['avg_handle_time'] ?? 0,
            'dialing_ratio'    => $this->calc->formatRatio($live, $campaign->pacing_mode),
            'calls_today'      => ['dialed'=>$results->count(),'answered'=>$results->where('disposition','ANSWERED')->count(),'busy'=>$results->where('disposition','BUSY')->count(),'no_answer'=>$results->where('disposition','NO ANSWER')->count(),'voicemail'=>$results->where('disposition','VOICEMAIL')->count(),'failed'=>$results->where('disposition','FAILED')->count()],
            'fcc_compliant'    => $campaign->abandonRateLive() < 3.0,
            'throttled'        => Cache::has("dialer:campaign:{$campaign->id}:throttle"),
            'started_at'       => $campaign->started_at?->toIso8601String(),
            'updated_at'       => now()->toIso8601String(),
        ]]);
    }

    /** @OA\Get(path="/dialer/metrics", tags={"Metrics"}, summary="Global metrics across all campaigns", security={{"bearerAuth":{}}},
     *   @OA\Response(response=200, description="Global summary")
     * )
     */
    public function global(): JsonResponse
    {
        return response()->json(['data' => ['campaigns_running'=>DialerCampaign::where('status','running')->count(),'campaigns_paused'=>DialerCampaign::where('status','paused')->count(),'campaigns_total'=>DialerCampaign::count(),'contacts_dialed_today'=>DialerCallResult::whereDate('called_at',today())->count(),'answer_rate_today'=>$this->globalAnswerRate(),'dnc_total'=>DialerDnc::count()]]);
    }

    /** @OA\Get(path="/dialer/metrics/realtime", tags={"Metrics"}, summary="Sub-second polling (Redis cache)", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="campaign_id", in="query", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Realtime stats")
     * )
     */
    public function realtime(Request $request): JsonResponse
    {
        $request->validate(['campaign_id' => 'required|uuid']);
        $campaign = DialerCampaign::findOrFail($request->campaign_id);
        $stats = Cache::get("dialer:campaign:{$campaign->id}:stats", []);
        $ans = $stats['total_answered'] ?? 0; $abn = $stats['total_abandoned'] ?? 0;
        return response()->json(['data' => ['campaign_id'=>$campaign->id,'status'=>$campaign->status,'active_calls'=>$stats['active_calls']??0,'calls_placed'=>$stats['total_dialed']??0,'answered'=>$ans,'abandon_rate'=>$ans>0?round($abn/$ans*100,2):0,'throttled'=>Cache::has("dialer:campaign:{$campaign->id}:throttle"),'ts'=>now()->toIso8601String()]]);
    }

    /** @OA\Get(path="/dialer/metrics/hourly", tags={"Metrics"}, summary="Hourly call breakdown", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="campaign_id", in="query", required=true, @OA\Schema(type="string")),
     *   @OA\Parameter(name="date", in="query", @OA\Schema(type="string", format="date")),
     *   @OA\Response(response=200, description="Hourly stats")
     * )
     */
    public function hourly(Request $request): JsonResponse
    {
        $request->validate(['campaign_id'=>'required|uuid','date'=>'nullable|date']);
        $date = $request->date ?? today()->toDateString();
        $rows = DialerCallResult::where('campaign_id',$request->campaign_id)->whereDate('called_at',$date)
            ->selectRaw("HOUR(called_at) as hour, COUNT(*) as dialed, SUM(disposition='ANSWERED') as answered, AVG(duration) as avg_duration")
            ->groupBy('hour')->orderBy('hour')->get();
        return response()->json(['data' => $rows, 'date' => $date]);
    }

    /** @OA\Get(path="/dialer/metrics/daily", tags={"Metrics"}, summary="Daily rolling window stats", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="days",        in="query", @OA\Schema(type="integer", default=7)),
     *   @OA\Parameter(name="campaign_id", in="query", @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Daily stats")
     * )
     */
    public function daily(Request $request): JsonResponse
    {
        $request->validate(['campaign_id'=>'nullable|uuid','days'=>'nullable|integer|max:90']);
        $days = (int)($request->days ?? 7);
        $q = DialerCallResult::selectRaw("DATE(called_at) as date, COUNT(*) as dialed, SUM(disposition='ANSWERED') as answered, AVG(duration) as avg_duration")
            ->where('called_at','>=',now()->subDays($days))->groupBy('date')->orderBy('date');
        if ($cid = $request->campaign_id) $q->where('campaign_id', $cid);
        return response()->json(['data' => $q->get()]);
    }

    /** @OA\Get(path="/dialer/metrics/pacing", tags={"Metrics"}, summary="Compare pacing modes with predicted abandon rates", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="campaign_id", in="query", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Pacing comparison")
     * )
     */
    public function pacing(Request $request): JsonResponse
    {
        $request->validate(['campaign_id' => 'required|uuid']);
        $campaign = DialerCampaign::findOrFail($request->campaign_id);
        $live = $this->engine->gatherMetrics($campaign);
        $ar   = $live['answer_rate'] ?? 0.30;
        return response()->json(['data' => ['current_mode'=>$campaign->pacing_mode,'answer_rate'=>round($ar*100,1),'abandon_rate'=>$campaign->abandonRateLive(),'modes'=>['conservative'=>['ratio'=>'1.2:1','predicted_abandon'=>round($this->calc->predictAbandonRate(1.2,$ar)*100,2).'%'],'moderate'=>['ratio'=>'2.4:1','predicted_abandon'=>round($this->calc->predictAbandonRate(2.4,$ar)*100,2).'%'],'aggressive'=>['ratio'=>'4.0:1','predicted_abandon'=>round($this->calc->predictAbandonRate(4.0,$ar)*100,2).'%']],'fcc_limit'=>'3%']]);
    }

    protected function globalAnswerRate(): float
    {
        $total = DialerCallResult::whereDate('called_at', today())->count();
        return $total > 0 ? round(DialerCallResult::whereDate('called_at',today())->where('disposition','ANSWERED')->count() / $total * 100, 1) : 0.0;
    }
}

// ════════════════════════════════════════════════════════════
// CALL RESULT CONTROLLER
// ════════════════════════════════════════════════════════════
class CallResultController extends Controller
{
    /** @OA\Get(path="/dialer/campaigns/{id}/results", tags={"Results"}, summary="List CDR results for campaign", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id",             in="path",  required=true, @OA\Schema(type="string")),
     *   @OA\Parameter(name="disposition",    in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="agent_answered", in="query", @OA\Schema(type="boolean")),
     *   @OA\Parameter(name="date",           in="query", @OA\Schema(type="string", format="date")),
     *   @OA\Parameter(name="per_page",       in="query", @OA\Schema(type="integer", default=25)),
     *   @OA\Response(response=200, description="Paginated CDR results")
     * )
     */
    public function index(Request $request, DialerCampaign $campaign): JsonResponse
    {
        $q = $campaign->results()->with('contact:id,phone,name')->latest('called_at');
        if ($d  = $request->query('disposition'))    $q->where('disposition', strtoupper($d));
        if ($request->query('agent_answered'))        $q->where('agent_answered', true);
        if ($dt = $request->query('date'))            $q->whereDate('called_at', $dt);
        $results = $q->paginate($request->query('per_page', 25));
        return response()->json(['data'=>CallResultResource::collection($results->items()),'meta'=>['total'=>$results->total(),'per_page'=>$results->perPage(),'current_page'=>$results->currentPage(),'last_page'=>$results->lastPage()]]);
    }

    /** @OA\Get(path="/dialer/campaigns/{id}/results/export", tags={"Results"}, summary="Export CDR to CSV", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="CSV download", @OA\MediaType(mediaType="text/csv"))
     * )
     */
    public function export(DialerCampaign $campaign): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        return response()->stream(function() use ($campaign) {
            $h = fopen('php://output', 'w');
            fputcsv($h, ['uuid','phone','name','disposition','duration_sec','agent_answered','called_at']);
            $campaign->results()->with('contact:id,phone,name')->chunk(500, function($rows) use ($h) {
                foreach ($rows as $r) fputcsv($h, [$r->uuid,$r->contact?->phone,$r->contact?->name,$r->disposition,$r->duration,$r->agent_answered?'yes':'no',$r->called_at?->toDateTimeString()]);
            });
            fclose($h);
        }, 200, ['Content-Type'=>'text/csv','Content-Disposition'=>"attachment; filename=\"{$campaign->name}-results.csv\""]);
    }

    /** @OA\Get(path="/dialer/results", tags={"Results"}, summary="All CDR results cross-campaign", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="campaign_id", in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="disposition",  in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="date",         in="query", @OA\Schema(type="string", format="date")),
     *   @OA\Response(response=200, description="Results")
     * )
     */
    public function all(Request $request): JsonResponse
    {
        $q = DialerCallResult::with(['contact:id,phone,name','campaign:id,name'])->latest('called_at');
        if ($c  = $request->query('campaign_id')) $q->where('campaign_id', $c);
        if ($d  = $request->query('disposition'))  $q->where('disposition', strtoupper($d));
        if ($dt = $request->query('date'))         $q->whereDate('called_at', $dt);
        return response()->json(CallResultResource::collection($q->paginate($request->query('per_page', 25))));
    }

    /** @OA\Get(path="/dialer/results/{result}", tags={"Results"}, summary="Get single call result", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="result", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Call result detail")
     * )
     */
    public function show(DialerCallResult $result): JsonResponse
    {
        return response()->json(['data' => new CallResultResource($result->load(['contact','campaign:id,name']))]);
    }
}

// ════════════════════════════════════════════════════════════
// DNC CONTROLLER
// ════════════════════════════════════════════════════════════
class DncController extends Controller
{
    /** @OA\Get(path="/dialer/dnc", tags={"DNC"}, summary="List DNC numbers", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="q",        in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="per_page", in="query", @OA\Schema(type="integer", default=50)),
     *   @OA\Response(response=200, description="DNC list")
     * )
     */
    public function index(Request $request): JsonResponse
    {
        $q = DialerDnc::latest('added_at');
        if ($k = $request->query('q')) $q->where('phone','like',"%{$k}%");
        $dnc = $q->paginate($request->query('per_page', 50));
        return response()->json(['data'=>$dnc->items(),'meta'=>['total'=>$dnc->total(),'per_page'=>$dnc->perPage()]]);
    }

    /** @OA\Post(path="/dialer/dnc", tags={"DNC"}, summary="Add number to DNC", security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"phone"},
     *     @OA\Property(property="phone",  type="string", example="+8801711000001"),
     *     @OA\Property(property="reason", type="string")
     *   )),
     *   @OA\Response(response=201, description="Added to DNC")
     * )
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate(['phone'=>'required|string|max:24','reason'=>'nullable|string|max:120']);
        $phone = preg_replace('/[^0-9+]/', '', trim($request->phone));
        $dnc   = DialerDnc::firstOrCreate(['phone'=>$phone],['reason'=>$request->reason??'Manual add','added_at'=>now()]);
        DialerContact::where('phone',$phone)->whereIn('status',['pending','dialing'])->update(['status'=>'dnc','disposition'=>'dnc']);
        return response()->json(['data'=>$dnc,'message'=>"{$phone} added to DNC."],201);
    }

    /** @OA\Post(path="/dialer/dnc/import", tags={"DNC"}, summary="Import DNC from CSV (phone column required)", security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\MediaType(mediaType="multipart/form-data",
     *     @OA\Schema(@OA\Property(property="file", type="string", format="binary"))
     *   )),
     *   @OA\Response(response=200, description="Imported")
     * )
     */
    public function import(Request $request): JsonResponse
    {
        $request->validate(['file'=>'required|file|mimes:csv,txt|max:10240']);
        $handle  = fopen($request->file('file')->getRealPath(),'r');
        $headers = array_map('strtolower', fgetcsv($handle));
        $count   = 0;
        while ($row = fgetcsv($handle)) {
            $data  = array_combine($headers, array_slice($row, 0, count($headers)));
            $phone = preg_replace('/[^0-9+]/', '', trim($data['phone'] ?? ''));
            if (empty($phone)) continue;
            DialerDnc::firstOrCreate(['phone'=>$phone],['reason'=>$data['reason']??'CSV import','added_at'=>now()]);
            $count++;
        }
        fclose($handle);
        return response()->json(['message'=>"{$count} numbers imported to DNC.",'count'=>$count]);
    }

    /** @OA\Get(path="/dialer/dnc/check/{phone}", tags={"DNC"}, summary="Check if phone is on DNC", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="phone", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="DNC status",
     *     @OA\JsonContent(
     *       @OA\Property(property="phone",    type="string"),
     *       @OA\Property(property="on_dnc",   type="boolean"),
     *       @OA\Property(property="reason",   type="string", nullable=true),
     *       @OA\Property(property="added_at", type="string", nullable=true)
     *     )
     *   )
     * )
     */
    public function check(string $phone): JsonResponse
    {
        $clean = preg_replace('/[^0-9+]/', '', trim($phone));
        $dnc   = DialerDnc::where('phone', $clean)->first();
        return response()->json(['phone'=>$clean,'on_dnc'=>(bool)$dnc,'reason'=>$dnc?->reason,'added_at'=>$dnc?->added_at?->toDateTimeString()]);
    }

    /** @OA\Delete(path="/dialer/dnc/{phone}", tags={"DNC"}, summary="Remove number from DNC", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="phone", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Removed")
     * )
     */
    public function destroy(string $phone): JsonResponse
    {
        $clean   = preg_replace('/[^0-9+]/', '', trim($phone));
        $deleted = DialerDnc::where('phone', $clean)->delete();
        return response()->json(['message' => $deleted ? "{$clean} removed from DNC." : "Not found on DNC."]);
    }

    /** @OA\Delete(path="/dialer/dnc", tags={"DNC"}, summary="Clear entire DNC — requires confirm=CLEAR_DNC", security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"confirm"},
     *     @OA\Property(property="confirm", type="string", enum={"CLEAR_DNC"})
     *   )),
     *   @OA\Response(response=200, description="Cleared")
     * )
     */
    public function destroyAll(Request $request): JsonResponse
    {
        $request->validate(['confirm' => 'required|in:CLEAR_DNC']);
        DialerDnc::truncate();
        return response()->json(['message' => 'DNC list cleared.']);
    }
}

// ════════════════════════════════════════════════════════════
// AGENT CONTROLLER — reads from FusionPBX PostgreSQL (read-only)
// ════════════════════════════════════════════════════════════
class AgentController extends Controller
{
    /** @OA\Get(path="/dialer/agents", tags={"Agents"}, summary="List agents from FusionPBX PostgreSQL", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="queue", in="query", @OA\Schema(type="string", example="Sales")),
     *   @OA\Response(response=200, description="Agent list with states")
     * )
     */
    public function index(Request $request): JsonResponse
    {
        $q = DB::connection('fusionpbx')->table('v_call_center_agents as a')
            ->leftJoin('v_call_center_tiers as t','a.agent_name','=','t.agent')
            ->select(['a.agent_uuid as id','a.agent_name as extension','a.agent_state as state','a.agent_status as status','a.calls_answered','a.no_answer_count','a.last_state_change','t.queue','t.tier_level as tier']);
        if ($queue = $request->query('queue')) $q->where('t.queue','like',"%{$queue}%");
        return response()->json(['data' => $q->get()]);
    }

    /** @OA\Get(path="/dialer/agents/available", tags={"Agents"}, summary="List idle/waiting agents only", security={{"bearerAuth":{}}},
     *   @OA\Response(response=200, description="Available agents")
     * )
     */
    public function available(): JsonResponse
    {
        $agents = DB::connection('fusionpbx')->table('v_call_center_agents')
            ->where('agent_state','Waiting')->get(['agent_uuid as id','agent_name as extension','agent_state as state','calls_answered']);
        return response()->json(['data'=>$agents,'count'=>$agents->count()]);
    }

    /** @OA\Get(path="/dialer/agents/{agent}", tags={"Agents"}, summary="Get single agent by UUID or extension", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="agent", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Agent detail"),
     *   @OA\Response(response=404, description="Not found")
     * )
     */
    public function show(string $agent): JsonResponse
    {
        $data = DB::connection('fusionpbx')->table('v_call_center_agents')
            ->where('agent_uuid',$agent)->orWhere('agent_name',$agent)->first();
        if (!$data) return response()->json(['error'=>'Agent not found.'],404);
        return response()->json(['data' => $data]);
    }
}

// ════════════════════════════════════════════════════════════
// WEBHOOK CONTROLLER — no auth, FreeSWITCH internal calls only
// ════════════════════════════════════════════════════════════
class WebhookController extends Controller
{
    /**
     * @OA\Post(path="/dialer/webhook/cdr", tags={"Webhooks"},
     *   summary="FreeSWITCH CDR webhook (no auth — 127.0.0.1 only)",
     *   description="xml_cdr.conf.xml: <param name='url' value='http://127.0.0.1:8092/api/v1/dialer/webhook/cdr'/>",
     *   @OA\RequestBody(@OA\JsonContent(
     *     @OA\Property(property="uuid",                          type="string"),
     *     @OA\Property(property="variable_dialer_call",          type="string", enum={"true","false"}),
     *     @OA\Property(property="hangup_cause",                  type="string"),
     *     @OA\Property(property="duration",                      type="string"),
     *     @OA\Property(property="variable_dialer_agent_answered", type="string", enum={"true","false"})
     *   )),
     *   @OA\Response(response=200, description="queued or skip")
     * )
     */
    public function cdr(Request $request): JsonResponse
    {
        $data      = $request->all();
        $uuid      = $data['variable_uuid'] ?? $data['uuid'] ?? null;
        $isDialer  = ($data['variable_dialer_call'] ?? 'false') === 'true';
        $cause     = $data['hangup_cause'] ?? $data['variable_hangup_cause'] ?? 'UNKNOWN';
        $duration  = (int)($data['duration'] ?? $data['variable_duration'] ?? 0);
        $agentAns  = ($data['variable_dialer_agent_answered'] ?? 'false') === 'true';
        if (!$isDialer || !$uuid) return response()->json(['status'=>'skip']);
        $disposition = $this->normalizeCause($cause);
        if ($disposition === 'ANSWERED' && !$agentAns && $duration >= 18 && $duration <= 45) $disposition = 'VOICEMAIL';
        HandleCallResultJob::dispatch($uuid, $disposition, $duration, $agentAns, $data)->onQueue('dialer');
        return response()->json(['status'=>'queued','uuid'=>$uuid]);
    }

    /** @OA\Post(path="/dialer/webhook/agent-state", tags={"Webhooks"}, summary="Agent state change from ESL",
     *   @OA\RequestBody(@OA\JsonContent(
     *     @OA\Property(property="agent", type="string", example="1001@default"),
     *     @OA\Property(property="state", type="string", example="Waiting")
     *   )),
     *   @OA\Response(response=200, description="Cached in Redis")
     * )
     */
    public function agentState(Request $request): JsonResponse
    {
        $agent = $request->input('agent');
        $state = $request->input('state');
        if ($agent && $state) Cache::put("dialer:agent-state:{$agent}", $state, 60);
        return response()->json(['status'=>'ok']);
    }

    /** @OA\Post(path="/dialer/webhook/call-event", tags={"Webhooks"}, summary="CHANNEL_ANSWER / CHANNEL_HANGUP events",
     *   @OA\RequestBody(@OA\JsonContent(
     *     @OA\Property(property="Event-Name",           type="string", example="CHANNEL_ANSWER"),
     *     @OA\Property(property="Unique-ID",            type="string"),
     *     @OA\Property(property="variable_campaign_id", type="string")
     *   )),
     *   @OA\Response(response=200, description="Processed")
     * )
     */
    public function callEvent(Request $request): JsonResponse
    {
        $event      = $request->input('Event-Name');
        $campaignId = $request->input('variable_campaign_id');
        if ($event === 'CHANNEL_ANSWER' && $campaignId) {
            $key   = "dialer:campaign:{$campaignId}:stats";
            $stats = Cache::get($key, []);
            $stats['active_calls'] = ($stats['active_calls'] ?? 0) + 1;
            Cache::put($key, $stats, 86400);
        }
        return response()->json(['status'=>'ok','event'=>$event]);
    }

    protected function normalizeCause(string $cause): string
    {
        return match(strtoupper($cause)) {
            'NORMAL_CLEARING'                                        => 'ANSWERED',
            'USER_BUSY'                                              => 'BUSY',
            'NO_ANSWER','NO_USER_RESPONSE','ORIGINATOR_CANCEL'       => 'NO ANSWER',
            'CALL_REJECTED','UNALLOCATED_NUMBER','INVALID_NUMBER_FORMAT' => 'INVALID_NUMBER',
            'NETWORK_OUT_OF_ORDER','RECOVERY_ON_TIMER_EXPIRE'        => 'FAILED',
            default                                                  => strtoupper($cause),
        };
    }
}
