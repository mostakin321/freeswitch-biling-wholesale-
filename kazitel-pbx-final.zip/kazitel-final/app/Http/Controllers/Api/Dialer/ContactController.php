<?php

namespace App\Http\Controllers\Api\Dialer;

use App\Http\Controllers\Controller;
use App\Http\Resources\Dialer\ContactResource;
use App\Models\Dialer\DialerCampaign;
use App\Models\Dialer\DialerContact;
use App\Models\Dialer\DialerDnc;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ContactController extends Controller
{
    /**
     * @OA\Get(path="/dialer/campaigns/{id}/contacts", tags={"Contacts"}, summary="List contacts for campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id",           in="path",  required=true, @OA\Schema(type="string")),
     *   @OA\Parameter(name="status",       in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="q",            in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="pending_only", in="query", @OA\Schema(type="boolean")),
     *   @OA\Parameter(name="per_page",     in="query", @OA\Schema(type="integer", default=25)),
     *   @OA\Response(response=200, description="Paginated contacts")
     * )
     */
    public function index(Request $request, DialerCampaign $campaign): JsonResponse
    {
        $q = $campaign->contacts()->latest();
        if ($s = $request->query('status')) $q->where('status', $s);
        if ($k = $request->query('q'))      $q->where(fn($s) => $s->where('phone','like',"%{$k}%")->orWhere('name','like',"%{$k}%"));
        if ($request->query('pending_only')) $q->pending();
        $contacts = $q->paginate($request->query('per_page', 25));
        return response()->json([
            'data' => ContactResource::collection($contacts->items()),
            'meta' => ['total'=>$contacts->total(),'per_page'=>$contacts->perPage(),'current_page'=>$contacts->currentPage(),'last_page'=>$contacts->lastPage(),
                'counts' => $campaign->contacts()->selectRaw('status, COUNT(*) as count')->groupBy('status')->pluck('count','status')],
        ]);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/contacts", tags={"Contacts"}, summary="Add single contact (DNC checked)",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"phone"},
     *     @OA\Property(property="phone",    type="string", example="+8801711000001"),
     *     @OA\Property(property="name",     type="string"),
     *     @OA\Property(property="email",    type="string"),
     *     @OA\Property(property="timezone", type="string"),
     *     @OA\Property(property="priority", type="integer", minimum=1, maximum=10)
     *   )),
     *   @OA\Response(response=201, description="Contact added"),
     *   @OA\Response(response=422, description="Number is on DNC list")
     * )
     */
    public function store(Request $request, DialerCampaign $campaign): JsonResponse
    {
        $data  = $request->validate(['phone'=>'required|string|max:24','name'=>'nullable|string|max:120','email'=>'nullable|email|max:120','timezone'=>'nullable|string|max:64','priority'=>'nullable|integer|between:1,10','custom_data'=>'nullable|array']);
        $phone = $this->normalizePhone($data['phone']);
        if (DialerDnc::where('phone', $phone)->exists())
            return response()->json(['error' => 'Number is on the Do Not Call list.', 'phone' => $phone], 422);
        $contact = $campaign->contacts()->create(array_merge($data, ['phone' => $phone, 'priority' => $data['priority'] ?? 5]));
        return response()->json(['data' => new ContactResource($contact), 'message' => 'Contact added.'], 201);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/contacts/import", tags={"Contacts"},
     *   summary="Bulk CSV import — DNC + duplicates auto-skipped. Max 50MB.",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\RequestBody(required=true, @OA\MediaType(mediaType="multipart/form-data",
     *     @OA\Schema(@OA\Property(property="file", type="string", format="binary"))
     *   )),
     *   @OA\Response(response=201, description="Import complete",
     *     @OA\JsonContent(
     *       @OA\Property(property="inserted",    type="integer"),
     *       @OA\Property(property="skipped_dnc", type="integer")
     *     )
     *   )
     * )
     */
    public function import(Request $request, DialerCampaign $campaign): JsonResponse
    {
        $request->validate(['file' => 'required|file|mimes:csv,txt|max:51200']);
        $handle  = fopen($request->file('file')->getRealPath(), 'r');
        $headers = array_map('strtolower', array_map('trim', fgetcsv($handle)));
        if (!in_array('phone', $headers)) {
            fclose($handle);
            return response()->json(['error' => "CSV missing required 'phone' column.", 'columns' => $headers], 422);
        }
        $dncSet    = DialerDnc::pluck('phone')->flip();
        $inserted  = 0;
        $skippedDnc = 0;
        $batch = [];
        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) < count($headers)) continue;
            $data  = array_combine($headers, $row);
            $phone = $this->normalizePhone($data['phone'] ?? '');
            if (empty($phone)) continue;
            if (isset($dncSet[$phone])) { $skippedDnc++; continue; }
            $batch[] = ['id'=>Str::uuid()->toString(),'campaign_id'=>$campaign->id,'phone'=>$phone,'name'=>$data['name']??null,'email'=>$data['email']??null,'timezone'=>$data['timezone']??null,'priority'=>(int)($data['priority']??5),'custom_data'=>json_encode($data),'status'=>'pending','attempt_count'=>0,'created_at'=>now(),'updated_at'=>now()];
            if (count($batch) >= 500) { DB::table('dialer_contacts')->insertOrIgnore($batch); $inserted += count($batch); $batch = []; }
        }
        if (!empty($batch)) { DB::table('dialer_contacts')->insertOrIgnore($batch); $inserted += count($batch); }
        fclose($handle);
        return response()->json(['message' => "{$inserted} contacts imported.", 'inserted' => $inserted, 'skipped_dnc' => $skippedDnc], 201);
    }

    /**
     * @OA\Delete(path="/dialer/campaigns/{id}/contacts", tags={"Contacts"}, summary="Delete ALL contacts from campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="All contacts deleted")
     * )
     */
    public function destroyAll(DialerCampaign $campaign): JsonResponse
    {
        if ($campaign->status === 'running') return response()->json(['error' => 'Stop campaign first.'], 422);
        $count = $campaign->contacts()->delete();
        return response()->json(['message' => "{$count} contacts deleted."]);
    }

    /** @OA\Get(path="/dialer/contacts/{contact}", tags={"Contacts"}, summary="Get contact detail", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="contact", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Contact detail")
     * )
     */
    public function show(DialerContact $contact): JsonResponse
    {
        return response()->json(['data' => new ContactResource($contact->load('campaign:id,name'))]);
    }

    /** @OA\Put(path="/dialer/contacts/{contact}", tags={"Contacts"}, summary="Update contact", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="contact", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Updated")
     * )
     */
    public function update(Request $request, DialerContact $contact): JsonResponse
    {
        $contact->update($request->only(['name','email','timezone','priority','custom_data']));
        return response()->json(['data' => new ContactResource($contact->fresh())]);
    }

    /** @OA\Delete(path="/dialer/contacts/{contact}", tags={"Contacts"}, summary="Delete contact", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="contact", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Deleted")
     * )
     */
    public function destroy(DialerContact $contact): JsonResponse
    {
        $contact->delete();
        return response()->json(['message' => 'Contact deleted.']);
    }

    /** @OA\Post(path="/dialer/contacts/{contact}/reschedule", tags={"Contacts"}, summary="Reschedule contact", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="contact", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"retry_after"},
     *     @OA\Property(property="retry_after", type="string", format="date-time"),
     *     @OA\Property(property="priority",    type="integer")
     *   )),
     *   @OA\Response(response=200, description="Rescheduled")
     * )
     */
    public function reschedule(Request $request, DialerContact $contact): JsonResponse
    {
        $request->validate(['retry_after' => 'required|date|after:now', 'priority' => 'nullable|integer|between:1,10']);
        $contact->update(['status' => 'pending','retry_after' => $request->retry_after,'priority' => $request->priority ?? $contact->priority]);
        return response()->json(['data' => new ContactResource($contact->fresh()), 'message' => 'Rescheduled.']);
    }

    /** @OA\Post(path="/dialer/contacts/{contact}/block", tags={"Contacts"}, summary="Block contact — adds to DNC", security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="contact", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\RequestBody(@OA\JsonContent(@OA\Property(property="reason", type="string"))),
     *   @OA\Response(response=200, description="Added to DNC")
     * )
     */
    public function block(Request $request, DialerContact $contact): JsonResponse
    {
        $request->validate(['reason' => 'nullable|string|max:120']);
        DialerDnc::firstOrCreate(['phone' => $contact->phone], ['reason' => $request->reason ?? 'Blocked via API','added_at' => now()]);
        $contact->update(['status' => 'dnc','disposition' => 'dnc']);
        return response()->json(['message' => "{$contact->phone} added to DNC."]);
    }

    protected function normalizePhone(string $phone): string
    {
        $clean = preg_replace('/[^0-9+]/', '', trim($phone));
        if (!str_starts_with($clean, '+') && strlen($clean) === 11) $clean = '+88' . $clean;
        return $clean;
    }
}
