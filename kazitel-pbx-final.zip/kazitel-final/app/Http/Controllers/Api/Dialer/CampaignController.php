<?php

namespace App\Http\Controllers\Api\Dialer;

use App\Http\Controllers\Controller;
use App\Http\Resources\Dialer\CampaignResource;
use App\Models\Dialer\DialerCampaign;
use App\Models\Dialer\DialerContact;
use App\Jobs\ProcessDialerCampaignJob;
use App\Services\PredictiveDialerEngine;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * @OA\Info(
 *   title="Kazitel PBX — Predictive Dialer API",
 *   version="1.0.0",
 *   description="Laravel 12 + Filament 4 + MySQL + FreeSWITCH ESL. Auth via Sanctum Bearer token.",
 *   @OA\Contact(email="support@kazitel.com")
 * )
 * @OA\Server(url="http://103.29.181.83:8092/api/v1", description="Kazitel PBX")
 * @OA\SecurityScheme(securityScheme="bearerAuth", type="http", scheme="bearer", bearerFormat="Sanctum")
 *
 * @OA\Tag(name="Auth",      description="Authentication")
 * @OA\Tag(name="Campaigns", description="Campaign management")
 * @OA\Tag(name="Contacts",  description="Lead list management")
 * @OA\Tag(name="Results",   description="CDR / call results")
 * @OA\Tag(name="DNC",       description="Do Not Call list")
 * @OA\Tag(name="Agents",    description="FusionPBX agents (PostgreSQL, read-only)")
 * @OA\Tag(name="Metrics",   description="Live and historical metrics")
 * @OA\Tag(name="Webhooks",  description="FreeSWITCH CDR webhooks (no auth)")
 *
 * @OA\Schema(schema="Campaign",
 *   @OA\Property(property="id",          type="string", format="uuid"),
 *   @OA\Property(property="name",        type="string", example="June Sales BD"),
 *   @OA\Property(property="status",      type="string", enum={"pending","running","paused","completed","archived"}),
 *   @OA\Property(property="pacing_mode", type="string", enum={"conservative","moderate","aggressive"}),
 *   @OA\Property(property="queue_name",  type="string", example="Sales"),
 *   @OA\Property(property="gateway_name",type="string", example="default"),
 *   @OA\Property(property="created_at",  type="string", format="date-time")
 * )
 * @OA\Schema(schema="Contact",
 *   @OA\Property(property="id",            type="string", format="uuid"),
 *   @OA\Property(property="phone",         type="string", example="+8801711000001"),
 *   @OA\Property(property="name",          type="string"),
 *   @OA\Property(property="status",        type="string", enum={"pending","dialing","answered","busy","no_answer","voicemail","dnc","failed","max_attempts","abandoned","cancelled"}),
 *   @OA\Property(property="attempt_count", type="integer"),
 *   @OA\Property(property="priority",      type="integer", minimum=1, maximum=10)
 * )
 * @OA\Schema(schema="CampaignMetrics",
 *   @OA\Property(property="campaign_id",      type="string"),
 *   @OA\Property(property="status",           type="string"),
 *   @OA\Property(property="progress_percent", type="number"),
 *   @OA\Property(property="active_calls",     type="integer"),
 *   @OA\Property(property="idle_agents",      type="integer"),
 *   @OA\Property(property="answer_rate",      type="number"),
 *   @OA\Property(property="abandon_rate",     type="number"),
 *   @OA\Property(property="dialing_ratio",    type="string", example="2.4:1"),
 *   @OA\Property(property="fcc_compliant",    type="boolean")
 * )
 * @OA\Schema(schema="Error",
 *   @OA\Property(property="error", type="string")
 * )
 */
class CampaignController extends Controller
{
    public function __construct(protected PredictiveDialerEngine $engine) {}

    /**
     * @OA\Get(path="/dialer/campaigns", tags={"Campaigns"}, summary="List all campaigns",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="status",      in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="pacing_mode", in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="q",           in="query", @OA\Schema(type="string")),
     *   @OA\Parameter(name="sort",        in="query", @OA\Schema(type="string", example="-created_at")),
     *   @OA\Parameter(name="per_page",    in="query", @OA\Schema(type="integer", default=15)),
     *   @OA\Response(response=200, description="Paginated campaigns")
     * )
     */
    public function index(Request $request): JsonResponse
    {
        $q = DialerCampaign::withCount(['contacts','results']);
        if ($s = $request->query('status'))      $q->where('status', $s);
        if ($m = $request->query('pacing_mode')) $q->where('pacing_mode', $m);
        if ($k = $request->query('q'))           $q->where('name', 'like', "%{$k}%");
        $sort = ltrim($request->query('sort','-created_at'), '-');
        $dir  = str_starts_with($request->query('sort','-created_at'), '-') ? 'desc' : 'asc';
        $q->orderBy(in_array($sort, ['name','status','created_at','started_at']) ? $sort : 'created_at', $dir);
        $campaigns = $q->paginate($request->query('per_page', 15));
        return response()->json([
            'data' => CampaignResource::collection($campaigns->items()),
            'meta' => ['total'=>$campaigns->total(),'per_page'=>$campaigns->perPage(),'current_page'=>$campaigns->currentPage(),'last_page'=>$campaigns->lastPage()],
        ]);
    }

    /**
     * @OA\Post(path="/dialer/campaigns", tags={"Campaigns"}, summary="Create a campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"name","pacing_mode","queue_name","gateway_name","caller_id_number"},
     *     @OA\Property(property="name",             type="string",  example="June Sales BD"),
     *     @OA\Property(property="pacing_mode",      type="string",  enum={"conservative","moderate","aggressive"}),
     *     @OA\Property(property="queue_name",       type="string",  example="Sales"),
     *     @OA\Property(property="gateway_name",     type="string",  example="default"),
     *     @OA\Property(property="caller_id_number", type="string",  example="09611123456"),
     *     @OA\Property(property="caller_id_name",   type="string",  example="Kazitel"),
     *     @OA\Property(property="timezone",         type="string",  example="Asia/Dhaka"),
     *     @OA\Property(property="max_attempts",     type="integer", example=3)
     *   )),
     *   @OA\Response(response=201, description="Campaign created"),
     *   @OA\Response(response=422, description="Validation error")
     * )
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'                  => 'required|string|max:120',
            'description'           => 'nullable|string|max:500',
            'pacing_mode'           => 'required|in:aggressive,moderate,conservative',
            'queue_name'            => 'required|string|max:64',
            'gateway_name'          => 'required|string|max:64',
            'caller_id_number'      => 'required|string|max:32',
            'caller_id_name'        => 'nullable|string|max:64',
            'calling_hours_start'   => 'nullable|integer|between:0,23',
            'calling_hours_end'     => 'nullable|integer|between:0,23',
            'timezone'              => 'nullable|string|max:64',
            'target_aht_seconds'    => 'nullable|integer|min:30|max:3600',
            'initial_answer_rate'   => 'nullable|numeric|between:1,100',
            'max_attempts'          => 'nullable|integer|between:1,10',
            'call_on_saturday'      => 'nullable|boolean',
            'call_on_sunday'        => 'nullable|boolean',
            'leave_voicemail'       => 'nullable|boolean',
        ]);
        $campaign = DialerCampaign::create(array_merge($data, [
            'status'              => 'pending',
            'calling_hours_start' => $data['calling_hours_start'] ?? 9,
            'calling_hours_end'   => $data['calling_hours_end']   ?? 20,
            'timezone'            => $data['timezone']             ?? 'Asia/Dhaka',
            'initial_answer_rate' => $data['initial_answer_rate'] ?? 30.0,
            'max_attempts'        => $data['max_attempts']         ?? 3,
            'target_aht_seconds'  => $data['target_aht_seconds']  ?? 180,
        ]));
        return response()->json(['data' => new CampaignResource($campaign), 'message' => 'Campaign created.'], 201);
    }

    /**
     * @OA\Get(path="/dialer/campaigns/{id}", tags={"Campaigns"}, summary="Get campaign by ID",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string", format="uuid")),
     *   @OA\Response(response=200, description="Campaign detail"),
     *   @OA\Response(response=404, description="Not found")
     * )
     */
    public function show(DialerCampaign $campaign): JsonResponse
    {
        return response()->json(['data' => new CampaignResource($campaign->loadCount(['contacts','results']))]);
    }

    /**
     * @OA\Put(path="/dialer/campaigns/{id}", tags={"Campaigns"}, summary="Update campaign (not while running)",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Updated"),
     *   @OA\Response(response=422, description="Cannot edit a running campaign")
     * )
     */
    public function update(Request $request, DialerCampaign $campaign): JsonResponse
    {
        if ($campaign->status === 'running')
            return response()->json(['error' => 'Stop the campaign before editing.'], 422);
        $campaign->update($request->validate([
            'name'                => 'sometimes|string|max:120',
            'description'         => 'nullable|string|max:500',
            'pacing_mode'         => 'sometimes|in:aggressive,moderate,conservative',
            'gateway_name'        => 'sometimes|string|max:64',
            'caller_id_number'    => 'sometimes|string|max:32',
            'caller_id_name'      => 'nullable|string|max:64',
            'calling_hours_start' => 'nullable|integer|between:0,23',
            'calling_hours_end'   => 'nullable|integer|between:0,23',
            'timezone'            => 'nullable|string|max:64',
            'target_aht_seconds'  => 'nullable|integer|min:30',
            'initial_answer_rate' => 'nullable|numeric|between:1,100',
            'max_attempts'        => 'nullable|integer|between:1,10',
            'call_on_saturday'    => 'nullable|boolean',
            'call_on_sunday'      => 'nullable|boolean',
            'leave_voicemail'     => 'nullable|boolean',
        ]));
        return response()->json(['data' => new CampaignResource($campaign->fresh()), 'message' => 'Updated.']);
    }

    /**
     * @OA\Delete(path="/dialer/campaigns/{id}", tags={"Campaigns"}, summary="Delete campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Deleted"),
     *   @OA\Response(response=422, description="Cannot delete a running campaign")
     * )
     */
    public function destroy(DialerCampaign $campaign): JsonResponse
    {
        if ($campaign->status === 'running')
            return response()->json(['error' => 'Stop the campaign first.'], 422);
        $campaign->delete();
        return response()->json(['message' => 'Campaign deleted.']);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/start", tags={"Campaigns"}, summary="Start campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Started"),
     *   @OA\Response(response=422, description="Cannot start — wrong status or no pending contacts")
     * )
     */
    public function start(DialerCampaign $campaign): JsonResponse
    {
        if (!$campaign->canStart())
            return response()->json(['error' => "Cannot start. Status: {$campaign->status}."], 422);
        ProcessDialerCampaignJob::dispatch($campaign)->onQueue('dialer');
        $campaign->update(['status' => 'running', 'started_at' => now()]);
        return response()->json(['data' => ['status' => 'running', 'started_at' => now()->toIso8601String()], 'message' => "Campaign '{$campaign->name}' started."]);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/stop", tags={"Campaigns"}, summary="Stop campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Stopped")
     * )
     */
    public function stop(DialerCampaign $campaign): JsonResponse
    {
        if (!in_array($campaign->status, ['running','paused']))
            return response()->json(['error' => 'Campaign is not running.'], 422);
        $this->engine->stopCampaign($campaign);
        return response()->json(['data' => ['status' => 'paused'], 'message' => 'Campaign stopped.']);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/pause", tags={"Campaigns"}, summary="Pause campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Paused")
     * )
     */
    public function pause(DialerCampaign $campaign): JsonResponse
    {
        if ($campaign->status !== 'running') return response()->json(['error' => 'Not running.'], 422);
        $campaign->update(['status' => 'paused']);
        return response()->json(['data' => ['status' => 'paused'], 'message' => 'Paused.']);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/resume", tags={"Campaigns"}, summary="Resume paused campaign",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Resumed")
     * )
     */
    public function resume(DialerCampaign $campaign): JsonResponse
    {
        if ($campaign->status !== 'paused') return response()->json(['error' => 'Not paused.'], 422);
        ProcessDialerCampaignJob::dispatch($campaign)->onQueue('dialer');
        $campaign->update(['status' => 'running']);
        return response()->json(['data' => ['status' => 'running'], 'message' => 'Resumed.']);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/reset", tags={"Campaigns"}, summary="Reset all contacts to pending",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=200, description="Reset complete")
     * )
     */
    public function reset(DialerCampaign $campaign): JsonResponse
    {
        if ($campaign->status === 'running') return response()->json(['error' => 'Stop campaign before reset.'], 422);
        $campaign->contacts()->update(['status' => 'pending','disposition' => null,'attempt_count' => 0,'last_called_at' => null,'retry_after' => null]);
        $campaign->update(['status' => 'pending','started_at' => null,'completed_at' => null]);
        return response()->json(['message' => "Reset. {$campaign->contacts()->count()} contacts back to pending."]);
    }

    /**
     * @OA\Post(path="/dialer/campaigns/{id}/clone", tags={"Campaigns"}, summary="Clone campaign with contacts",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\Response(response=201, description="Clone created")
     * )
     */
    public function clone(DialerCampaign $campaign): JsonResponse
    {
        $clone = $campaign->replicate(['started_at','completed_at']);
        $clone->name   = $campaign->name . ' (copy)';
        $clone->status = 'pending';
        $clone->save();
        $campaign->contacts()->chunk(500, function($contacts) use ($clone) {
            $rows = $contacts->map(fn($c) => array_merge(
                $c->only(['phone','name','email','timezone','priority','custom_data']),
                ['id'=>Str::uuid()->toString(),'campaign_id'=>$clone->id,'status'=>'pending','attempt_count'=>0,'created_at'=>now(),'updated_at'=>now()]
            ))->toArray();
            DialerContact::insert($rows);
        });
        return response()->json(['data' => new CampaignResource($clone->loadCount('contacts')), 'message' => 'Cloned.'], 201);
    }

    /**
     * @OA\Patch(path="/dialer/campaigns/{id}/pacing", tags={"Campaigns"}, summary="Update pacing mode live",
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="string")),
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"pacing_mode"},
     *     @OA\Property(property="pacing_mode",         type="string", enum={"conservative","moderate","aggressive"}),
     *     @OA\Property(property="target_aht_seconds",  type="integer"),
     *     @OA\Property(property="initial_answer_rate", type="number")
     *   )),
     *   @OA\Response(response=200, description="Pacing updated")
     * )
     */
    public function updatePacing(Request $request, DialerCampaign $campaign): JsonResponse
    {
        $data = $request->validate([
            'pacing_mode'         => 'required|in:aggressive,moderate,conservative',
            'target_aht_seconds'  => 'nullable|integer|min:30',
            'initial_answer_rate' => 'nullable|numeric|between:1,100',
        ]);
        $campaign->update($data);
        return response()->json(['data' => $campaign->fresh()->only(['pacing_mode','target_aht_seconds','initial_answer_rate']), 'message' => "Pacing updated to {$campaign->pacing_mode}."]);
    }
}
