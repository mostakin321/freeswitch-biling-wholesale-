<?php
namespace App\Services\AI;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
class AiCopilotService
{
    protected string $apiKey;
    protected string $model;
    protected bool   $enabled;
    public function __construct()
    {
        $wl           = config('whitelabel');
        $this->enabled = (bool)($wl['openai_enabled'] ?? false);
        $this->apiKey  = $wl['openai_key']   ?? '';
        $this->model   = $wl['openai_model'] ?? 'gpt-4o';
    }
    public function isEnabled(): bool { return $this->enabled && !empty($this->apiKey); }
    public function analyzeSentiment(string $transcript): array
    {
        if (!$this->isEnabled()) return ['sentiment'=>'neutral','score'=>50,'summary'=>''];
        $response = $this->chat([['role'=>'system','content'=>'Analyze call sentiment. Respond only in JSON with keys: sentiment (positive|neutral|negative), score (0-100), summary (1 sentence).'],['role'=>'user','content'=>$transcript]]);
        return json_decode($response, true) ?? ['sentiment'=>'neutral','score'=>50,'summary'=>$response];
    }
    public function agentCoaching(array $metrics): string
    {
        if (!$this->isEnabled()) return '';
        return $this->chat([['role'=>'system','content'=>'You are a call center AI coach. Give 3 short actionable coaching tips.'],['role'=>'user','content'=>'Agent metrics: ' . json_encode($metrics)]]);
    }
    public function summarizeVoicemail(string $transcript): string
    {
        if (!$this->isEnabled()) return '';
        return $this->chat([['role'=>'system','content'=>'Summarize this voicemail in 1-2 sentences. Include intent, urgency, and if callback is needed.'],['role'=>'user','content'=>$transcript]]);
    }
    public function chat(array $messages, int $maxTokens = 500): string
    {
        if (!$this->isEnabled()) return '';
        try {
            $response = Http::withHeaders(['Authorization'=>'Bearer '.$this->apiKey,'Content-Type'=>'application/json'])
                ->post('https://api.openai.com/v1/chat/completions',['model'=>$this->model,'messages'=>$messages,'max_tokens'=>$maxTokens])->json();
            return $response['choices'][0]['message']['content'] ?? '';
        } catch (\Throwable $e) {
            Log::error('[AiCopilot] ' . $e->getMessage());
            return '';
        }
    }
}
