<?php
namespace App\Services;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
class AgentAvailabilityMonitor
{
    public function getAvailableAgents(string $queue = ''): array
    {
        try {
            $q = DB::connection('fusionpbx')->table('v_call_center_agents as a')
                ->leftJoin('v_call_center_tiers as t','a.agent_name','=','t.agent')
                ->where('a.agent_state','Waiting')->where('a.agent_status','Available');
            if ($queue) $q->where('t.queue','like',"%{$queue}%");
            return $q->get(['a.agent_uuid','a.agent_name','a.agent_state','t.queue'])->toArray();
        } catch (\Throwable $e) {
            Log::warning('[AgentMonitor] PostgreSQL query failed: ' . $e->getMessage());
            return [];
        }
    }
    public function getIdleCount(string $queue = ''): int
    {
        return count($this->getAvailableAgents($queue));
    }
    public function updateCache(string $campaignId, array $metrics): void
    {
        Cache::put("dialer:campaign:{$campaignId}:stats", $metrics, 30);
    }
}
