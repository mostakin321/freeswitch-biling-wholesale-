<?php
namespace App\Services;
use Illuminate\Support\Facades\Log;
class FreeSwitchDialerService
{
    protected $socket = null;
    protected string $host;
    protected int    $port;
    protected string $password;
    public function __construct()
    {
        $this->host     = config('services.freeswitch.esl_host', env('FREESWITCH_ESL_HOST', '127.0.0.1'));
        $this->port     = (int)config('services.freeswitch.esl_port', env('FREESWITCH_ESL_PORT', 8021));
        $this->password = config('services.freeswitch.esl_password', env('FREESWITCH_ESL_PASSWORD', 'ClueCon'));
    }
    public function connect(): bool
    {
        try {
            $this->socket = fsockopen($this->host, $this->port, $errno, $errstr, 5);
            if (!$this->socket) return false;
            $this->read(); // Content-Type: auth/request
            fwrite($this->socket, "auth {$this->password}\n\n");
            $resp = $this->read();
            return str_contains($resp, '+OK accepted');
        } catch (\Throwable $e) {
            Log::error('[ESL] Connect failed: ' . $e->getMessage());
            return false;
        }
    }
    public function originate(string $phone, string $gateway, string $queue, string $callerId, array $vars = []): ?string
    {
        $uuid  = \Illuminate\Support\Str::uuid()->toString();
        $extra = '';
        foreach (array_merge(['dialer_call'=>'true','origination_uuid'=>$uuid], $vars) as $k=>$v) {
            $extra .= "{$k}={$v},";
        }
        $cmd = "bgapi originate {" . rtrim($extra,',') . "}sofia/gateway/{$gateway}/{$phone} &transfer('{$queue} XML default')";
        fwrite($this->socket, "api {$cmd}\n\n");
        return $uuid;
    }
    public function hangup(string $uuid): void
    {
        if ($this->socket) fwrite($this->socket, "api uuid_kill {$uuid}\n\n");
    }
    public function getActiveCalls(): int
    {
        if (!$this->socket) return 0;
        fwrite($this->socket, "api show channels count\n\n");
        $resp = $this->read();
        preg_match('/(\d+) total/', $resp, $m);
        return (int)($m[1] ?? 0);
    }
    public function disconnect(): void
    {
        if ($this->socket) { fclose($this->socket); $this->socket = null; }
    }
    protected function read(): string
    {
        $out = '';
        while ($line = fgets($this->socket, 1024)) {
            $out .= $line;
            if (trim($line) === '') break;
        }
        return $out;
    }
}
