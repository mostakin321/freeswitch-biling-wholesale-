<?php
namespace App\Services;
class DialingRatioCalculator
{
    private array $ratios = ['conservative' => 1.2, 'moderate' => 2.4, 'aggressive' => 4.0];
    public function calculate(array $metrics, string $mode = 'moderate'): int
    {
        $idle = $metrics['idle_agents'] ?? 0;
        if ($idle <= 0) return 0;
        $ratio      = $this->ratios[$mode] ?? 2.4;
        $answerRate = max(0.05, $metrics['answer_rate'] ?? 0.30);
        return (int) ceil($idle * $ratio / $answerRate);
    }
    public function formatRatio(array $metrics, string $mode): string
    {
        return ($this->ratios[$mode] ?? 2.4) . ':1';
    }
    public function predictAbandonRate(float $ratio, float $answerRate): float
    {
        $overflow = max(0, ($ratio * $answerRate) - 1.0);
        return min(0.30, $overflow / max(0.001, $ratio * $answerRate));
    }
}
