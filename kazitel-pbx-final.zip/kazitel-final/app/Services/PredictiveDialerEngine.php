<?php
namespace App\Services;
use App\Models\Dialer\DialerCampaign;
use Illuminate\Support\Facades\Cache;
class PredictiveDialerEngine
{
    public function gatherMetrics(DialerCampaign $campaign): array
    {
        $stats = Cache::get("dialer:campaign:{$campaign->id}:stats", []);
        return [
            'active_calls'    => $stats['active_calls']    ?? 0,
            'idle_agents'     => $stats['idle_agents']     ?? 0,
            'busy_agents'     => $stats['busy_agents']     ?? 0,
            'total_agents'    => ($stats['idle_agents'] ?? 0) + ($stats['busy_agents'] ?? 0),
            'answer_rate'     => ($campaign->initial_answer_rate ?? 30) / 100,
            'abandon_rate'    => 0.0,
            'avg_handle_time' => $campaign->target_aht_seconds ?? 180,
            'occupancy'       => 0.0,
        ];
    }
    public function stopCampaign(DialerCampaign $campaign): void
    {
        Cache::forget("dialer:campaign:{$campaign->id}:running");
        $campaign->update(['status' => 'paused']);
    }
}
