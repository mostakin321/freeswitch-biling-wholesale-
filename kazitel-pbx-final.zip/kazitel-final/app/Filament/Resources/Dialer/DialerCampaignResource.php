<?php
namespace App\Filament\Resources\Dialer;
use App\Filament\Resources\Dialer\DialerCampaignResource\Pages;
use App\Jobs\ProcessDialerCampaignJob;
use App\Models\Dialer\DialerCampaign;
use App\Services\PredictiveDialerEngine;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
class DialerCampaignResource extends Resource
{
    protected static ?string $model           = DialerCampaign::class;
    protected static ?string $navigationGroup = 'Predictive Dialer';
    protected static ?string $navigationIcon  = 'heroicon-o-phone-arrow-up-right';
    protected static ?string $navigationLabel = 'Campaigns';
    protected static ?int    $navigationSort  = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Campaign Info')->schema([
                Forms\Components\TextInput::make('name')->required()->maxLength(120)->columnSpan(2),
                Forms\Components\Textarea::make('description')->rows(2)->columnSpan(2),
                Forms\Components\Select::make('pacing_mode')->options(['conservative'=>'Conservative (1.2:1)','moderate'=>'Moderate (2.4:1)','aggressive'=>'Aggressive (4:1)'])->required()->default('moderate'),
                Forms\Components\TextInput::make('queue_name')->required()->placeholder('Sales'),
                Forms\Components\TextInput::make('gateway_name')->required()->default('default'),
                Forms\Components\TextInput::make('caller_id_number')->required(),
                Forms\Components\TextInput::make('caller_id_name')->nullable(),
            ])->columns(2),
            Forms\Components\Section::make('Schedule')->schema([
                Forms\Components\TextInput::make('calling_hours_start')->numeric()->default(9)->label('Start Hour'),
                Forms\Components\TextInput::make('calling_hours_end')->numeric()->default(20)->label('End Hour'),
                Forms\Components\Select::make('timezone')->options(['Asia/Dhaka'=>'Asia/Dhaka (BD)','UTC'=>'UTC'])->default('Asia/Dhaka'),
                Forms\Components\TextInput::make('max_attempts')->numeric()->default(3),
                Forms\Components\Toggle::make('call_on_saturday')->default(true),
                Forms\Components\Toggle::make('call_on_sunday')->default(false),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('name')->searchable()->sortable()->weight('bold'),
            Tables\Columns\TextColumn::make('status')->badge()->color(fn($state)=>match($state){'running'=>'success','paused'=>'warning','pending'=>'gray','completed'=>'primary',default=>'gray'}),
            Tables\Columns\TextColumn::make('pacing_mode')->badge()->color(fn($state)=>match($state){'conservative'=>'success','moderate'=>'warning','aggressive'=>'danger',default=>'gray'}),
            Tables\Columns\TextColumn::make('queue_name')->label('Queue'),
            Tables\Columns\TextColumn::make('contacts_count')->counts('contacts')->label('Contacts'),
            Tables\Columns\TextColumn::make('results_count')->counts('results')->label('Dialed'),
            Tables\Columns\TextColumn::make('created_at')->dateTime()->sortable(),
        ])
        ->actions([
            Tables\Actions\Action::make('start')->icon('heroicon-o-play')->color('success')
                ->visible(fn($record)=>$record->canStart())
                ->action(function($record){
                    ProcessDialerCampaignJob::dispatch($record)->onQueue('dialer');
                    $record->update(['status'=>'running','started_at'=>now()]);
                    Notification::make()->title('Campaign started!')->success()->send();
                }),
            Tables\Actions\Action::make('stop')->icon('heroicon-o-stop')->color('danger')
                ->visible(fn($record)=>$record->status==='running')->requiresConfirmation()
                ->action(function($record){
                    app(PredictiveDialerEngine::class)->stopCampaign($record);
                    Notification::make()->title('Campaign stopped.')->warning()->send();
                }),
            Tables\Actions\EditAction::make(),
            Tables\Actions\DeleteAction::make()->visible(fn($record)=>$record->status!=='running'),
        ])
        ->filters([
            Tables\Filters\SelectFilter::make('status')->options(['pending'=>'Pending','running'=>'Running','paused'=>'Paused','completed'=>'Completed']),
            Tables\Filters\SelectFilter::make('pacing_mode')->options(['conservative'=>'Conservative','moderate'=>'Moderate','aggressive'=>'Aggressive']),
        ]);
    }

    public static function getPages(): array
    {
        return ['index'=>Pages\ListDialerCampaigns::route('/'),'create'=>Pages\CreateDialerCampaign::route('/create'),'edit'=>Pages\EditDialerCampaign::route('/{record}/edit')];
    }

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::whereIn('status',['running','paused'])->count() ?: null;
    }
    public static function getNavigationBadgeColor(): ?string { return 'success'; }
}
