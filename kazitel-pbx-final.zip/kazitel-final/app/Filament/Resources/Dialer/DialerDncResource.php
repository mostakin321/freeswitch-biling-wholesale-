<?php
namespace App\Filament\Resources\Dialer;
use App\Filament\Resources\Dialer\DialerDncResource\Pages;
use App\Models\Dialer\DialerDnc;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
class DialerDncResource extends Resource
{
    protected static ?string $model           = DialerDnc::class;
    protected static ?string $navigationGroup = 'Predictive Dialer';
    protected static ?string $navigationIcon  = 'heroicon-o-no-symbol';
    protected static ?string $navigationLabel = 'DNC List';
    protected static ?int    $navigationSort  = 3;
    public static function form(Form $form): Form
    {
        return $form->schema([Forms\Components\TextInput::make('phone')->required()->maxLength(24),Forms\Components\TextInput::make('reason')->maxLength(120)]);
    }
    public static function table(Table $table): Table
    {
        return $table->columns([Tables\Columns\TextColumn::make('phone')->searchable()->copyable(),Tables\Columns\TextColumn::make('reason'),Tables\Columns\TextColumn::make('added_at')->dateTime()->sortable()])
            ->actions([Tables\Actions\DeleteAction::make()])
            ->bulkActions([Tables\Actions\BulkActionGroup::make([Tables\Actions\DeleteBulkAction::make()])]);
    }
    public static function getPages(): array
    {
        return ['index'=>Pages\ListDialerDnc::route('/'),'create'=>Pages\CreateDialerDnc::route('/create')];
    }
    public static function getNavigationBadge(): ?string { return static::getModel()::count() ?: null; }
}
