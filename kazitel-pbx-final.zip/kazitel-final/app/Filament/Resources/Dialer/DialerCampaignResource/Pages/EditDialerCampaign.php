<?php
namespace App\Filament\Resources\Dialer\DialerCampaignResource\Pages;
use App\Filament\Resources\Dialer\DialerCampaignResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
class EditDialerCampaign extends EditRecord
{
    protected static string $resource = DialerCampaignResource::class;
    protected function getHeaderActions(): array { return [Actions\DeleteAction::make()]; }
}
