<?php
namespace App\Filament\Resources\Dialer\DialerCampaignResource\Pages;
use App\Filament\Resources\Dialer\DialerCampaignResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;
class CreateDialerCampaign extends CreateRecord
{
    protected static string $resource = DialerCampaignResource::class;
    
}
