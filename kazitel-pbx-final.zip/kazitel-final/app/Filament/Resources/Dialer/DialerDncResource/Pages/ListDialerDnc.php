<?php
namespace App\Filament\Resources\Dialer\DialerDncResource\Pages;
use App\Filament\Resources\Dialer\DialerDncResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
class ListDialerDnc extends ListRecords
{
    protected static string $resource = DialerDncResource::class;
    protected function getHeaderActions(): array { return [Actions\CreateAction::make()]; }
}
