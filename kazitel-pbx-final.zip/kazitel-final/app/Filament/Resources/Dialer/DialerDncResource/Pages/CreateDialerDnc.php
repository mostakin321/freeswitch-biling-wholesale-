<?php
namespace App\Filament\Resources\Dialer\DialerDncResource\Pages;
use App\Filament\Resources\Dialer\DialerDncResource;
use Filament\Resources\Pages\CreateRecord;
class CreateDialerDnc extends CreateRecord
{
    protected static string $resource = DialerDncResource::class;
}
