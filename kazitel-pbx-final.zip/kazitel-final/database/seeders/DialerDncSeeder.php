<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * DNC Seeder — MySQL (kazitel_pbx)
 * Seeds sample Do Not Call numbers
 * Run: php artisan db:seed --class=DialerDncSeeder
 */
class DialerDncSeeder extends Seeder
{
    public function run(): void
    {
        $this->command->info('Seeding DNC list (MySQL)...');

        $dncNumbers = [
            ['phone' => '+8801700000000', 'reason' => 'Customer opted out',       'added_at' => now()],
            ['phone' => '+8801800000000', 'reason' => 'Legal hold — do not call', 'added_at' => now()],
            ['phone' => '+8801900000000', 'reason' => 'Test DNC number',           'added_at' => now()],
            ['phone' => '+8801600000000', 'reason' => 'Regulatory blacklist',      'added_at' => now()],
            ['phone' => '+8801500000000', 'reason' => 'Agent requested removal',   'added_at' => now()],
        ];

        foreach ($dncNumbers as &$entry) {
            $entry['created_at'] = now();
            $entry['updated_at'] = now();
        }

        DB::table('dialer_dnc')->insertOrIgnore($dncNumbers);
        $this->command->info('  ✓ ' . count($dncNumbers) . ' DNC numbers seeded');
    }
}
