<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Dialer Campaign Seeder — MySQL (kazitel_pbx)
 * Seeds 3 campaigns + 10 contacts each
 * Run: php artisan db:seed --class=DialerCampaignSeeder
 */
class DialerCampaignSeeder extends Seeder
{
    public function run(): void
    {
        $this->command->info('Seeding dialer campaigns (MySQL)...');

        $campaigns = [
            [
                'id'                    => Str::uuid()->toString(),
                'name'                  => 'June Sales BD',
                'description'           => 'Bangladesh sales outreach - June 2026',
                'status'                => 'pending',
                'pacing_mode'           => 'moderate',
                'queue_name'            => 'Sales',
                'gateway_name'          => 'default',
                'caller_id_number'      => '09611123456',
                'caller_id_name'        => 'Kazitel',
                'calling_hours_start'   => 9,
                'calling_hours_end'     => 20,
                'timezone'              => 'Asia/Dhaka',
                'call_on_saturday'      => 1,
                'call_on_sunday'        => 0,
                'target_aht_seconds'    => 180,
                'initial_answer_rate'   => 35.00,
                'max_attempts'          => 3,
                'leave_voicemail'       => 0,
                'created_at'            => now(),
                'updated_at'            => now(),
            ],
            [
                'id'                    => Str::uuid()->toString(),
                'name'                  => 'Support Follow-Up',
                'description'           => 'Follow-up on open support tickets',
                'status'                => 'pending',
                'pacing_mode'           => 'conservative',
                'queue_name'            => 'Support',
                'gateway_name'          => 'default',
                'caller_id_number'      => '09611123457',
                'caller_id_name'        => 'Kazitel Support',
                'calling_hours_start'   => 10,
                'calling_hours_end'     => 18,
                'timezone'              => 'Asia/Dhaka',
                'call_on_saturday'      => 0,
                'call_on_sunday'        => 0,
                'target_aht_seconds'    => 240,
                'initial_answer_rate'   => 40.00,
                'max_attempts'          => 2,
                'leave_voicemail'       => 1,
                'created_at'            => now(),
                'updated_at'            => now(),
            ],
            [
                'id'                    => Str::uuid()->toString(),
                'name'                  => 'Payment Reminder',
                'description'           => 'Monthly payment reminder for overdue accounts',
                'status'                => 'pending',
                'pacing_mode'           => 'aggressive',
                'queue_name'            => 'Billing',
                'gateway_name'          => 'default',
                'caller_id_number'      => '09611123458',
                'caller_id_name'        => 'Kazitel Billing',
                'calling_hours_start'   => 9,
                'calling_hours_end'     => 19,
                'timezone'              => 'Asia/Dhaka',
                'call_on_saturday'      => 1,
                'call_on_sunday'        => 0,
                'target_aht_seconds'    => 120,
                'initial_answer_rate'   => 30.00,
                'max_attempts'          => 3,
                'leave_voicemail'       => 0,
                'created_at'            => now(),
                'updated_at'            => now(),
            ],
        ];

        foreach ($campaigns as $campaign) {
            DB::table('dialer_campaigns')->insertOrIgnore($campaign);
        }

        $this->command->info('  ✓ ' . count($campaigns) . ' campaigns seeded');

        // Seed 10 contacts per campaign
        $sampleContacts = [
            ['+8801711000001', 'Rahim Ali',      'rahim@example.com'],
            ['+8801711000002', 'Karim Hossain',  'karim@example.com'],
            ['+8801711000003', 'Sara Begum',      'sara@example.com'],
            ['+8801711000004', 'Omar Faruk',      'omar@example.com'],
            ['+8801711000005', 'Nadia Islam',     'nadia@example.com'],
            ['+8801711000006', 'Jamal Uddin',     'jamal@example.com'],
            ['+8801711000007', 'Rima Akter',      'rima@example.com'],
            ['+8801711000008', 'Salam Khan',      'salam@example.com'],
            ['+8801711000009', 'Fariha Noor',     'fariha@example.com'],
            ['+8801711000010', 'Imran Ahmed',     'imran@example.com'],
        ];

        $totalContacts = 0;
        foreach ($campaigns as $idx => $campaign) {
            $contacts = [];
            // Offset phone numbers per campaign to avoid duplicates
            foreach ($sampleContacts as $i => [$phone, $name, $email]) {
                $offsetPhone = '+880171' . str_pad(($idx * 100) + $i + 1, 7, '0', STR_PAD_LEFT);
                $contacts[] = [
                    'id'            => Str::uuid()->toString(),
                    'campaign_id'   => $campaign['id'],
                    'phone'         => $offsetPhone,
                    'name'          => $name,
                    'email'         => $email,
                    'timezone'      => 'Asia/Dhaka',
                    'priority'      => ($i < 3) ? 1 : 5,
                    'status'        => 'pending',
                    'attempt_count' => 0,
                    'custom_data'   => json_encode(['source' => 'seed', 'campaign' => $campaign['name']]),
                    'created_at'    => now(),
                    'updated_at'    => now(),
                ];
            }
            DB::table('dialer_contacts')->insertOrIgnore($contacts);
            $totalContacts += count($contacts);
        }

        $this->command->info("  ✓ {$totalContacts} contacts seeded across " . count($campaigns) . ' campaigns');
    }
}
