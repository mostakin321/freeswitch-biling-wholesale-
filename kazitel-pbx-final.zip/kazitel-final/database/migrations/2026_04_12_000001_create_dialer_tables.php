<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Kazitel PBX — Dialer Tables Migration
 * Database: MySQL (kazitel_pbx)
 * Run: php artisan migrate --force
 */
return new class extends Migration
{
    protected $connection = 'mysql';

    public function up(): void
    {
        // ── Campaigns ────────────────────────────────────────────
        Schema::create('dialer_campaigns', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name', 120);
            $table->text('description')->nullable();
            $table->enum('status', ['pending','running','paused','completed','archived'])->default('pending')->index();
            $table->enum('pacing_mode', ['conservative','moderate','aggressive'])->default('moderate');
            $table->string('queue_name', 64);
            $table->string('gateway_name', 64)->default('default');
            $table->string('caller_id_number', 32);
            $table->string('caller_id_name', 64)->nullable();
            $table->tinyInteger('calling_hours_start')->default(9);
            $table->tinyInteger('calling_hours_end')->default(20);
            $table->string('timezone', 64)->default('Asia/Dhaka');
            $table->boolean('call_on_saturday')->default(true);
            $table->boolean('call_on_sunday')->default(false);
            $table->unsignedSmallInteger('target_aht_seconds')->default(180);
            $table->decimal('initial_answer_rate', 5, 2)->default(30.00);
            $table->tinyInteger('max_attempts')->default(3);
            $table->boolean('leave_voicemail')->default(false);
            $table->string('voicemail_file', 255)->nullable();
            $table->string('abandoned_message_file', 255)->nullable();
            $table->uuid('domain_uuid')->nullable()->index();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['status','pacing_mode']);
        });

        // ── Contacts / Lead List ──────────────────────────────────
        Schema::create('dialer_contacts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('campaign_id')->index();
            $table->string('phone', 24)->index();
            $table->string('name', 120)->nullable();
            $table->string('email', 120)->nullable();
            $table->string('timezone', 64)->nullable();
            $table->tinyInteger('priority')->default(5)->index();
            $table->enum('status', ['pending','dialing','answered','busy','no_answer','voicemail','dnc','failed','max_attempts','abandoned','cancelled'])->default('pending')->index();
            $table->string('disposition', 64)->nullable();
            $table->tinyInteger('attempt_count')->default(0);
            $table->timestamp('last_called_at')->nullable();
            $table->timestamp('retry_after')->nullable()->index();
            $table->json('custom_data')->nullable();
            $table->timestamps();

            $table->foreign('campaign_id')->references('id')->on('dialer_campaigns')->onDelete('cascade');
            $table->unique(['campaign_id','phone']);
            $table->index(['campaign_id','status','priority','retry_after']);
        });

        // ── Call Results / CDR ───────────────────────────────────
        Schema::create('dialer_call_results', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('campaign_id')->index();
            $table->uuid('contact_id')->nullable()->index();
            $table->string('uuid', 64)->unique()->comment('FreeSWITCH call UUID');
            $table->string('disposition', 32)->index();
            $table->unsignedSmallInteger('duration')->default(0)->comment('seconds');
            $table->boolean('agent_answered')->default(false)->index();
            $table->string('agent_extension', 32)->nullable();
            $table->timestamp('called_at')->nullable()->index();
            $table->json('raw_cdr')->nullable();
            $table->timestamps();

            $table->foreign('campaign_id')->references('id')->on('dialer_campaigns')->onDelete('cascade');
            $table->index(['campaign_id','disposition','called_at']);
        });

        // ── DNC List ──────────────────────────────────────────────
        Schema::create('dialer_dnc', function (Blueprint $table) {
            $table->id();
            $table->string('phone', 24)->unique()->index();
            $table->string('reason', 120)->nullable();
            $table->uuid('domain_uuid')->nullable();
            $table->timestamp('added_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dialer_call_results');
        Schema::dropIfExists('dialer_contacts');
        Schema::dropIfExists('dialer_campaigns');
        Schema::dropIfExists('dialer_dnc');
    }
};
