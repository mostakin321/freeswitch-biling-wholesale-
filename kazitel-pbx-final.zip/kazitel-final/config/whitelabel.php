<?php
return [
    'app_name'      => env('WL_APP_NAME',    env('APP_NAME', 'Kazitel PBX')),
    'company_name'  => env('WL_COMPANY',     'Kazitel'),
    'tagline'       => env('WL_TAGLINE',     'Powered by FreeSWITCH'),
    'logo_url'      => env('WL_LOGO_URL',    null),
    'favicon_url'   => env('WL_FAVICON_URL', null),
    'support_email' => env('WL_SUPPORT_EMAIL', 'support@kazitel.com'),
    'address'       => env('WL_ADDRESS',     'Shibganj, Bogura, Bangladesh'),
    'phone'         => env('WL_PHONE',       ''),
    'primary_color' => env('WL_PRIMARY_COLOR', 'amber'),
    'primary_hex'   => env('WL_PRIMARY_HEX',   null),
    'admin_path'    => env('WL_ADMIN_PATH',   'admin'),
    'dark_mode'     => env('WL_DARK_MODE',    false),
    'openai_enabled'=> env('OPENAI_ENABLED',  false),
    'openai_key'    => env('OPENAI_API_KEY',  ''),
    'openai_model'  => env('OPENAI_MODEL',    'gpt-4o'),
    'openai_features' => [
        'call_transcription' => env('AI_TRANSCRIPTION', false),
        'sentiment_analysis' => env('AI_SENTIMENT',     false),
        'agent_coaching'     => env('AI_COACHING',      false),
        'voicemail_summary'  => env('AI_VOICEMAIL',     false),
    ],
];
