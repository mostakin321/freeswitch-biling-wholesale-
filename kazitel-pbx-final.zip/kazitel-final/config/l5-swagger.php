<?php
/**
 * L5-Swagger OpenAPI config
 * Install:  composer require darkaonline/l5-swagger
 * Generate: php artisan l5-swagger:generate
 * View:     http://your-server/api/documentation
 */
return [
    'default' => 'default',
    'documentations' => [
        'default' => [
            'api'    => ['title' => 'Kazitel PBX — Predictive Dialer API'],
            'routes' => ['api' => 'api/documentation'],
            'paths'  => [
                'docs'        => storage_path('api-docs'),
                'docs_json'   => 'api-docs.json',
                'annotations' => [base_path('app/Http/Controllers/Api/Dialer')],
                'views'       => base_path('resources/views/vendor/l5-swagger'),
                'base'        => null,
                'swagger_ui_assets_path' => 'vendor/swagger-api/swagger-ui/dist/',
                'excludes'    => [],
            ],
        ],
    ],
    'defaults' => [
        'routes'  => ['docs'=>'docs','oauth2_callback'=>'api/oauth2-callback','middleware'=>['api'=>[],'asset'=>[],'docs'=>[],'oauth2_callback'=>[]],'group_options'=>[]],
        'paths'   => ['docs'=>storage_path('api-docs'),'views'=>base_path('resources/views/vendor/l5-swagger'),'base'=>null,'swagger_ui_assets_path'=>'vendor/swagger-api/swagger-ui/dist/','excludes'=>[]],
        'scanOptions' => ['default_processors_configuration'=>[],'analyser'=>null,'analysis'=>null,'processors'=>[],'pattern'=>null,'exclude'=>[],'open_api_spec_version'=>\L5Swagger\Generator::OPEN_API_DEFAULT_SPEC_VERSION],
        'securityDefinitions' => ['securitySchemes'=>['bearerAuth'=>['type'=>'http','scheme'=>'bearer','bearerFormat'=>'Sanctum']],'security'=>[['bearerAuth'=>[]]]],
        'generate_always'    => env('L5_SWAGGER_GENERATE_ALWAYS', false),
        'generate_yaml_copy' => env('L5_SWAGGER_GENERATE_YAML_COPY', false),
        'proxy'              => false,
        'additional_config_url' => null,
        'operations_sort'    => null,
        'validator_url'      => null,
        'ui'                 => ['display'=>['doc_expansion'=>'none','filter'=>true],'authorization'=>['persist_authorization'=>false,'oauth2'=>['use_pkce_with_authorization_code_grant'=>false]]],
        'constants'          => ['L5_SWAGGER_CONST_HOST'=>env('L5_SWAGGER_CONST_HOST','http://103.29.181.83:8092')],
    ],
];
